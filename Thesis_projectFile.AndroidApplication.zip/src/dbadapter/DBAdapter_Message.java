package dbadapter;

import yjh.meb.rememberbox.R;
import yjh.meb.rememberbox.R.id;
import yjh.meb.rememberbox.R.layout;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

public class DBAdapter_Message extends CursorAdapter{
	// Ŀ���� ��� ������ �����ͼ� ������ ����Ʈ�信 ������ ����Ʈ���� ���̾ƿ� ���÷��Ϳ� ��ġ�ϴ� �۾�
	int count = 0;
	int count2 = 0;

	public DBAdapter_Message(Context context, Cursor c) {
		super(context, c);
	}

	@Override
	public void bindView(View view, Context context, Cursor cursor) {
		TextView incommingnumberTextView = (TextView)view.findViewById(R.id.listincommingnumber);
		TextView bodyTextView = (TextView)view.findViewById(R.id.listbody);
		TextView timestampTextView = (TextView)view.findViewById(R.id.listtimestamp);
		TextView srTextView = (TextView)view.findViewById(R.id.listsr);
		
		incommingnumberTextView.setText(cursor.getString(cursor.getColumnIndex("number")));
		srTextView.setText(cursor.getString(cursor.getColumnIndex("sr")));
		bodyTextView.setText(cursor.getString(cursor.getColumnIndex("body")));
		timestampTextView.setText(cursor.getString(cursor.getColumnIndex("timestamp")));
		Log.i("info","bindView"+(count++));
	}

	@Override
	public View newView(Context context, Cursor cursor, ViewGroup parent) {
		LayoutInflater lif = LayoutInflater.from(context);
		View v = lif.inflate(R.layout.message_list_layout, parent, false);
		Log.i("info","newView"+(count2++));
		return v;
	}

}
