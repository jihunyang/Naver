package observer;

import java.io.File;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;
import java.util.Date;

import dbmanager.DBManager_Message;

import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;

public class SmsSentObserver extends ContentObserver {
	
	private static final String TAG = "remember";
    private static Uri STATUS_URI;
	//private static final Uri STATUS_URI = Uri.parse("content://com.sec.mms.provider/message");
    private Context mContext;
    DBManager_Message dbm;
    
	public SmsSentObserver(Handler handler, Context ctx, Uri uri) {
		super(handler);
		mContext = ctx;
		STATUS_URI = uri;
	}

	public boolean deliverSelfNotifications() {
		return true;
	}

	public String parseDate(long time) {
		SimpleDateFormat sdf = new SimpleDateFormat(
				"yyyy'/'MM'/'dd' 'HH':'mm':'ss");
		Date dd = new Date(time);
		return sdf.format(dd);
	}
	
	//���� ���ؽ�Ʈ���� sms�� ���� ���� ������ �����ؼ� Ŀ���� �Ѱ���
	//Ŀ������ �߽Ź�ȣ, ����, �ð��� �����ͼ� DB�� ����
	public void onChange(boolean selfChange) {
		dbm = new DBManager_Message(mContext);
		try {
			Cursor sms_sent_cursor = mContext.getContentResolver().query(STATUS_URI, null, null, null, null);
	        if (sms_sent_cursor != null) {
	        	boolean movefirst = sms_sent_cursor.moveToFirst();
		        if (movefirst) {
		        	String protocol = "";
		        	protocol = sms_sent_cursor.getString(sms_sent_cursor.getColumnIndex("protocol"));
		        	int sms_type = sms_sent_cursor.getInt(sms_sent_cursor.getColumnIndex("type"));
		        	if(protocol == null && sms_type==6){//�߽Ÿ޽���
		        		dbm.open();
		        		dbm.createValue(sms_sent_cursor.getString(sms_sent_cursor.getColumnIndex("address")), "���� �߽�", sms_sent_cursor.getString(sms_sent_cursor.getColumnIndex("body")), parseDate(sms_sent_cursor.getLong(sms_sent_cursor.getColumnIndex("date"))));
		        		dbm.close();
		        		LOGG(TAG, "*****************************");
		        		LOGG(TAG, "�߽�");
		        		LOGG(TAG, "Address : " + sms_sent_cursor.getString(sms_sent_cursor.getColumnIndex("address")));
		        		LOGG(TAG, "Body : " + sms_sent_cursor.getString(sms_sent_cursor.getColumnIndex("body")));
		        		LOGG(TAG, "Date : " + parseDate(sms_sent_cursor.getLong(sms_sent_cursor.getColumnIndex("date"))));
		        		LOGG(TAG, "*****************************");
		        	}
		        }
	        }
	        else
	        	LOGG(TAG, "Send Cursor is Empty");
		}
		catch(Exception sggh){
			LOGG(TAG, "Error on onChange : "+sggh.toString());
		}
		super.onChange(selfChange);
	}//fn onChange
	public void LOGG(String tag, String body)
    {
    	Log.d("remember", body);
    	String dir_path = mContext.getFilesDir().getAbsolutePath();
    	String file_path = dir_path + "/log.txt";
    	File f = new File(dir_path);
    	if(!f.exists())
    	{
    		f.mkdirs();
    	}
    	try{
    		RandomAccessFile raf = new RandomAccessFile(file_path, "rw");
    		raf.seek(raf.length());
    		SimpleDateFormat sd = new SimpleDateFormat(
    				"yy'/'MM'/'dd'.'HH':'mm':'ss");
    		String now = sd.format(System.currentTimeMillis()) + " :: ";
    		raf.write(now.getBytes());
    		raf.write(body.getBytes());
    		raf.write("\n".getBytes());
    		raf.close();
    	}catch(Exception e)
    	{}
    }
	
}//End of class SmsSentObserver
