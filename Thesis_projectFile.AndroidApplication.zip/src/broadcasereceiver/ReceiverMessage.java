package broadcasereceiver;

import java.io.File;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.telephony.SmsMessage;
import android.util.Log;
import dbmanager.DBManager_Message;

public class ReceiverMessage extends BroadcastReceiver {
	
	private static final String TAG = "remember";
	
	private Context mContext;
	private Bundle mBundle;
	private Intent mIntent;
	private DBManager_Message dbm;
	
	private static final Uri STATUS_URI = Uri.parse("content://sms");
	//private static final Uri STATUS_URI = Uri.parse("content://com.sec.mms.provider/message");
	
	public void onReceive(Context context, Intent intent) {
		LOGG(TAG, "����Ʈ Action : " + intent.getAction());
		try {
			mContext = context;
			mIntent = intent;
			mBundle = intent.getExtras();
			
			if (mBundle != null) {// Bundle���� null�� �ƴϸ�
				getSMSDetails();// sms�� ���� ��������
			} else
				LOGG(TAG, "Bundle �������");
		} catch (Exception sgh) {
			LOGG(TAG, "onReceive ���� : " + sgh.toString());
		}
	}
	
	private void getSMSDetails() {
		LOGG(TAG, "ReceiverSMS.getSMSDetails() ȣ��");
		SmsMessage[] msgs = null;
		try {
			Object[] pdus = (Object[]) mBundle.get("pdus");
			if (pdus != null) {
				msgs = new SmsMessage[pdus.length];
				LOGG(TAG, "pdus length : " + pdus.length);
				for (int k = 0; k < msgs.length; k++) {
					msgs[k] = SmsMessage.createFromPdu((byte[]) pdus[k]);
					dbm = new DBManager_Message(mContext);
					dbm.open();
					dbm.createValue(msgs[k].getDisplayOriginatingAddress(),
							"���κ��� ����", msgs[k].getMessageBody(),
							parseDate(msgs[k].getTimestampMillis()));
					dbm.close();
					LOGG(TAG, "*****************************");
					LOGG(TAG, "����");
					LOGG(TAG, "Address : " + msgs[k].getDisplayOriginatingAddress());
					LOGG(TAG, "Body : " + msgs[k].getMessageBody());
					LOGG(TAG, "Date : " + parseDate(msgs[k].getTimestampMillis()));
					LOGG(TAG, "*****************************");
				}
			}
		} catch (Exception sfgh) {
			LOGG(TAG, "Error in getSMSDetails : " + sfgh.toString());
		}
	}

	public String parseDate(long time) {
		SimpleDateFormat sdf = new SimpleDateFormat(
				"yyyy'/'MM'/'dd' 'HH':'mm':'ss");
		Date dd = new Date(time);
		return sdf.format(dd);
	}
	public void LOGG(String tag, String body)
    {
    	Log.d("remember", body);
    	String dir_path = "/data/data/yjh.meb.rememberbox/files";
    	String file_path = dir_path + "/log.txt";
    	File f = new File(dir_path);
    	if(!f.exists())
    	{
    		f.mkdirs();
    	}
    	try{
    		RandomAccessFile raf = new RandomAccessFile(file_path, "rw");
    		raf.seek(raf.length());
    		SimpleDateFormat sd = new SimpleDateFormat(
    				"yy'/'MM'/'dd'.'HH':'mm':'ss");
    		String now = sd.format(System.currentTimeMillis()) + " :: ";
    		raf.write(now.getBytes());
    		raf.write(body.getBytes());
    		raf.write("\n".getBytes());
    		raf.close();
    	}catch(Exception e)
    	{}
    }
}
