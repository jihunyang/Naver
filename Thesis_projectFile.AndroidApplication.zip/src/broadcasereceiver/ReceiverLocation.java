package broadcasereceiver;

import java.io.File;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.location.LocationManager;
import android.os.Environment;
import android.os.Vibrator;
import android.util.Log;
import android.widget.Toast;

public class ReceiverLocation extends BroadcastReceiver {
	Context mcontext;
	@Override
	public void onReceive(Context context, Intent intent) {
	    mcontext = context;
		boolean isEntering = intent.getBooleanExtra(LocationManager.KEY_PROXIMITY_ENTERING, true);
	    LOGG("remember", "���ù������̼� intent�� ���پ˶����� : "+isEntering);
	    if(isEntering)
	    {
	    	Intent i = new Intent(context, activity.Alram_loc.class);
	    	i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
	    	context.startActivity(i);
	    	Toast.makeText(context, "��ǥ ������ ������..", Toast.LENGTH_LONG).show();
	    }
	    else
	    {
	    	Toast.makeText(context, "��ǥ �������� ����ϴ�.", Toast.LENGTH_LONG).show();
	    }
	}
	public void LOGG(String tag, String body)
    {
    	Log.d("remember", body);
    	String dir_path = mcontext.getFilesDir().getAbsolutePath();
    	String file_path = dir_path + "/log.txt";
    	File f = new File(dir_path);
    	if(!f.exists())
    	{
    		f.mkdirs();
    	}
    	try{
    		RandomAccessFile raf = new RandomAccessFile(file_path, "rw");
    		raf.seek(raf.length());
    		SimpleDateFormat sd = new SimpleDateFormat(
    				"yy'/'MM'/'dd'.'HH':'mm':'ss");
    		String now = sd.format(System.currentTimeMillis()) + " :: ";
    		raf.write(now.getBytes());
    		raf.write(body.getBytes());
    		raf.write("\n".getBytes());
    		raf.close();
    	}catch(Exception e)
    	{}
    }
}
