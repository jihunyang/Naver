package broadcasereceiver;

import service.Service_boot;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class ReceiverBoot extends BroadcastReceiver{

	public void onReceive(Context context, Intent intent) {
		Intent i = new Intent(context, Service_boot.class);
		i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		ComponentName cn = context.startService(i);
		Toast.makeText(context, "��Ʈ���ù� �۵�" + cn.toString(), Toast.LENGTH_LONG).show();
	}
}
