package broadcasereceiver;

import java.io.File;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;

import service.Service_Record;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Environment;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;

public class PhoneListener extends PhoneStateListener{
	private Context context;
	public PhoneListener(Context c) {
		context = c;
	}
	
	public void onCallStateChanged(int state, String incomingNumber) {
		LOGG("remember", "��ȭ���� ��ȭ ������ �۵�");
		switch (state) {
		case TelephonyManager.CALL_STATE_IDLE: //��ȭ ��� ����
			Boolean stopped = context.stopService(new Intent(context,
					Service_Record.class));
			LOGG("remember", "RecordService ���� ���ϰ� : " + stopped);
			break;
		case TelephonyManager.CALL_STATE_RINGING:
			LOGG("remember", "��ȭ�� �︮�� ��");
			break;
		case TelephonyManager.CALL_STATE_OFFHOOK: //��ȭ ������ ����
			Intent callIntent = new Intent(context, Service_Record.class);
			ComponentName name = context.startService(callIntent);
			if (null == name) {
				LOGG("CallRecorder", "���� ���� ���ϰ��� null��");
			} else {
				LOGG("CallRecorder", "���� ���� ���� ��  " + name.flattenToString());
			}
			break;
		}
	}
	public void LOGG(String tag, String body)
    {
    	Log.d("remember", body);
    	String dir_path = context.getFilesDir().getAbsolutePath();
    	String file_path = dir_path + "/log.txt";
    	File f = new File(dir_path);
    	if(!f.exists())
    	{
    		f.mkdirs();
    	}
    	try{
    		RandomAccessFile raf = new RandomAccessFile(file_path, "rw");
    		raf.seek(raf.length());
    		SimpleDateFormat sd = new SimpleDateFormat(
    				"yy'/'MM'/'dd'.'HH':'mm':'ss");
    		String now = sd.format(System.currentTimeMillis()) + " :: ";
    		raf.write(now.getBytes());
    		raf.write(body.getBytes());
    		raf.write("\n".getBytes());
    		raf.close();
    	}catch(Exception e)
    	{}
    }
}
