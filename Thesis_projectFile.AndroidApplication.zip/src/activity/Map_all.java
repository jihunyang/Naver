package activity;

import java.util.ArrayList;
import java.util.List;


import values.LocationVALUE;
import yjh.meb.rememberbox.R;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

import dbmanager.DBManager_Location;

public class Map_all extends MapActivity{
	MapView mapView;
	MapController controller;
	
	Drawable drawable;
	List<Overlay> mapOverlays;
	ArrayList<LocationVALUE> locarray;
	MyItemizedOverlay itemizedOverlay;
	OverlayItem overlayItem;
	
	GeoPoint point =new GeoPoint((int)(35.178298*1E6), (int)(126.908913*1E6));
	DBManager_Location dbm;
	Cursor cursor;
	
	public void onCreate(Bundle savedInstancesState) {
		super.onCreate(savedInstancesState);
		setContentView(R.layout.activity_map_all);
		
		locarray = new ArrayList<LocationVALUE>();
		dbm = new DBManager_Location(getApplicationContext());
		mapView = (MapView) findViewById(R.id.myMap_all);
		mapView.setBuiltInZoomControls(true);		
		mapView.setSatellite(false);
		
		controller = mapView.getController();		
		mapOverlays = mapView.getOverlays();
		
		drawable = getResources().getDrawable(R.drawable.pin);
		itemizedOverlay = new MyItemizedOverlay(drawable, mapView);
		
		
		dbm.open();
		cursor = dbm.fetchAllValues();
		
		if (cursor.getCount() > 0) {
			startManagingCursor(cursor);
			while(cursor.moveToNext())
			{
				LocationVALUE lv = new LocationVALUE(
						cursor.getDouble(cursor.getColumnIndex("lat")),
						cursor.getDouble(cursor.getColumnIndex("lng")),
						cursor.getString(cursor.getColumnIndex("provider")),
						cursor.getString(cursor.getColumnIndex("address")),
						cursor.getString(cursor.getColumnIndex("time")));
				locarray.add(lv);
			}
			cursor.close();
			dbm.close();
		}
		else
		{
			finish();
			cursor.close();
			dbm.close();
		}
		

		for (LocationVALUE l : locarray) {
			if (l.getLat() != 0 && l.getLng() != 0) {
				point = new GeoPoint((int) (l.getLat() * 1E6),
						(int) (l.getLng() * 1E6));
				overlayItem = new OverlayItem(point, l.getTime(),
						l.getAddress());
				itemizedOverlay.addOverlay(overlayItem);
			}
		}
		mapOverlays.add(itemizedOverlay);

		/*
		//�������� �߰� �κ�
		point = new GeoPoint((int)(35.178263*1E6), (int)(126.909213*1E6));
		Log.d("remember", point.getLatitudeE6() + " " + point.getLongitudeE6());
		OverlayItem overlayItem = new OverlayItem(point, "��ĥ", "��ĥ�Դϴ�.");
		itemizedOverlay.addOverlay(overlayItem);
		mapOverlays.add(itemizedOverlay);
		//������
		*/
		
		controller.animateTo(point);
		controller.setZoom(17);
		
	}
	protected boolean isRouteDisplayed() {
		return false;
	}
}