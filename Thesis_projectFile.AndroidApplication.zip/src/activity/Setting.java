package activity;

import java.io.File;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;

import observer.SmsSentObserver;
import service.Service_Alert_test;
import service.Service_Message;
import yjh.meb.rememberbox.R;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.preference.Preference;
import android.preference.Preference.OnPreferenceClickListener;
import android.preference.PreferenceActivity;
import android.preference.PreferenceManager;
import android.util.Log;

public class Setting extends PreferenceActivity implements OnSharedPreferenceChangeListener {
	Preference Location_use;
	Preference Location_gosetting;
	Preference Location_checktime;
	
	Preference Location_bannotice;
	Preference Location_banrange;
	Preference Location_banadd;

	Preference CALL_use;
	Preference CALL_input;
	Preference CALL_format;
	Preference MESSAGE_use;
	
	boolean gpsenable = false;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		gpsenable = ckGPS();//gps��밡������ üũ
		
		SharedPreferences pref = getPreferenceManager().getSharedPreferences();
		pref.registerOnSharedPreferenceChangeListener(this); //�������� �� ���� ������ ���

		addPreferencesFromResource(R.xml.activity_settings); //���� xml �ҷ��ͼ� ȭ�鿡 �Ѹ�
		PreferenceManager.setDefaultValues(Setting.this, R.xml.activity_settings, false);//����Ʈ ������ �ʱ�ȭ
		
		Location_use = findPreference("Location_use");
		Location_gosetting = findPreference("Location_gosetting");
		Location_checktime = findPreference("Location_checktime");
		
		Location_bannotice = findPreference("Location_bannotice");
		Location_banrange = findPreference("Location_banrange");		
		Location_banadd = findPreference("Location_banadd");
		
		CALL_use = findPreference("CALL_use");
		CALL_input = findPreference("AUDIO_SOURCE");
		CALL_format = findPreference("AUDIO_FORMAT");
		MESSAGE_use = findPreference("MESSAGE_use");
		
		Location_gosetting.setOnPreferenceClickListener(new OnPreferenceClickListener() {//gps ����â���� ����
					public boolean onPreferenceClick(Preference preference) {
						Intent intent = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
						intent.addCategory(Intent.CATEGORY_DEFAULT);
						startActivity(intent);
						return false;
					}
				});
		Location_banadd.setOnPreferenceClickListener(new OnPreferenceClickListener() {//�������� ���� ��Ƽ��Ƽ
					public boolean onPreferenceClick(Preference preference) {
						startActivity(new Intent(Setting.this, Map_ban.class));
						return false;
					}
				});
		checkoption(); //�ɼ� ���ù�ư�� enable ����
	}

	public void onSharedPreferenceChanged(SharedPreferences pref, String key) {
		LOGG("remember", key+"�Է�");
		if (key.equals("Location_use")&& pref.getBoolean("Location_use", false)) {// ��ġ��������ϰ�, ���� Ʈ���
			start_loc_info();
		} else if (key.equals("Location_use")&& !pref.getBoolean("Location_use", false)) {
			stop_loc_info();
		} else if (key.equals("Location_bannotice")&& pref.getBoolean("Location_bannotice", false)) {
			Location_banrange.setEnabled(false);
			Location_banadd.setEnabled(false);
			LOGG("remember", "sharedpreferenceChanged start_banArea");
			start_banArea();
		} else if (key.equals("Location_bannotice")&& !pref.getBoolean("Location_bannotice", false)) {
			Location_banrange.setEnabled(true);
			Location_banadd.setEnabled(true);
			LOGG("remember", "sharedpreferenceChanged stop_banArea");
			stop_banArea();
		} else if (key.equals("CALL_use") && pref.getBoolean("CALL_use", false)){
			CALL_format.setEnabled(false);
			CALL_input.setEnabled(false);
			LOGG("remember", "��ȭ���� ���");
		} else if (key.equals("CALL_use") && !pref.getBoolean("CALL_use", false)){
			CALL_format.setEnabled(true);
			CALL_input.setEnabled(true);
			LOGG("remember", "��ȭ���� ����");
		} else if (key.equals("MESSAGE_use") && pref.getBoolean("MESSAGE_use", false)){
			start_messagelog();
			LOGG("remember", "�޽��� �α� ���");
		} else if (key.equals("MESSAGE_use") && !pref.getBoolean("MESSAGE_use", false)){
			LOGG("remember", "�޽��� �α� ����");
			stop_messagelog();
		}
	}
	
	
	void start_messagelog()
	{
		startService(new Intent(this, Service_Message.class));
	}

	void stop_messagelog()
	{
		stopService(new Intent(this, Service_Message.class));
	}

	void start_loc_info() {		
		// ��ġ ���� �������� ����(�ѹ��� ����Ǵ°�) �����ϰ� �˶� ���
		//�������ϵ��� ����
		Location_gosetting.setEnabled(false);
		Location_checktime.setEnabled(false);
		//�˶��Ŵ��� �����ϰ� Service_LOC_info ������ �׼ǰ����� ����Ʈ �����ѵ�
		//�˶��Ŵ����� �ش� ���񽺸� �ݺ� �����ϵ��� ���
		AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
		Intent i = new Intent("yjh.meb.Location");
		PendingIntent pi = PendingIntent.getService(Setting.this, 0, i, 0);		
		am.setRepeating(AlarmManager.RTC, System.currentTimeMillis(), getTimming(), pi);
		LOGG("remember", "�˶��Ŵ����� ���, �ֱ� : "+getTimming());
	}

	void stop_loc_info() {
		// ��ġ���� �������� ���� ����� �˶� ����
		Location_gosetting.setEnabled(true);
		Location_checktime.setEnabled(true);
		//�˶��Ŵ������� �ݺ�����
		AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
		Intent i = new Intent("yjh.meb.Location");
		PendingIntent pi = PendingIntent.getService(Setting.this, 0, i, 0);
		am.cancel(pi);
		pi.cancel();
		try{
			stopService(i);
		}catch(Exception e){
			LOGG("remember", "stopservice����");
		}
		LOGG("remember", "�˶��Ŵ��� ����");
	}
	
	void start_banArea()
	{
		startService(new Intent(this, Service_Alert_test.class));
		LOGG("remember", "�˸����� ���");
	}
	void stop_banArea()
	{
		stopService(new Intent(this, Service_Alert_test.class));
		LOGG("remember", "�˸����� ����");
	}
	
	public void GPSAlert() {
		try{
		AlertDialog.Builder gsDialog = new AlertDialog.Builder(Setting.this);
		gsDialog.setTitle("GPS ���� : off");
		gsDialog.setMessage("GPS�� �����ִ� ��� ��Ȯ�� ��ġ�� ã�� ��ƽ��ϴ�.\nGPS�� �����Ͻðڽ��ϱ�?");
		gsDialog.setPositiveButton("Ȯ��", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				// GPS���� ȭ������ Ƣ���
				Intent intent = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
				intent.addCategory(Intent.CATEGORY_DEFAULT);
				startActivity(intent);
			}
		});
		gsDialog.setNegativeButton("���", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
			}
		});
		AlertDialog alert = gsDialog.create();
		alert.show();
		}catch(Exception e)
		{
			LOGG("remember",e.toString());
		}
	}

	public boolean ckGPS() {
		String gs = android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.LOCATION_PROVIDERS_ALLOWED);
		if (gs.indexOf("gps", 0) < 0) {// GPS����
			LOGG("remember", "gps�����ִ��� Ȯ��false");
			return false;
		} else{
			LOGG("remember", "gps�����ִ��� Ȯ��true");
			return true;// GPS����
		}			
	}
	
	public void checkoption()
	{
		SharedPreferences pref = getSharedPreferences(
				"yjh.meb.rememberbox_preferences", MODE_WORLD_READABLE);
		if(pref.getBoolean("Location_use", false))
		{
			Location_gosetting.setEnabled(false);
			Location_checktime.setEnabled(false);
		}
		if(pref.getBoolean("Location_bannotice", false))
		{
			Location_banrange.setEnabled(false);
			Location_banadd.setEnabled(false);
		}
		if(pref.getBoolean("CALL_use", false))
		{
			CALL_input.setEnabled(false);
			CALL_format.setEnabled(false);
		}
}
	
	public int getTimming()
	{
		SharedPreferences pref = getSharedPreferences(
				"yjh.meb.rememberbox_preferences", MODE_WORLD_READABLE);
		int temp = Integer.parseInt(pref.getString("Location_checktime", "5"))*1000 * 60;
		LOGG("remember", "getTimming()��" + temp);
		return temp;
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
	}
	public void LOGG(String tag, String body)
    {
    	Log.d("remember", body);
    	String dir_path = getFilesDir().getAbsolutePath();
    	String file_path = dir_path + "/log.txt";
    	File f = new File(dir_path);
    	if(!f.exists())
    	{
    		f.mkdirs();
    	}
    	try{
    		RandomAccessFile raf = new RandomAccessFile(file_path, "rw");
    		raf.seek(raf.length());
    		SimpleDateFormat sd = new SimpleDateFormat(
    				"yy'/'MM'/'dd'.'HH':'mm':'ss");
    		String now = sd.format(System.currentTimeMillis()) + " :: ";
    		raf.write(now.getBytes());
    		raf.write(body.getBytes());
    		raf.write("\n".getBytes());
    		raf.close();
    	}catch(Exception e)
    	{}
    }
}
