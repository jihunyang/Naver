package activity;

import yjh.meb.rememberbox.R;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Alram_loc extends Activity implements android.view.View.OnClickListener{

	Button b;
    Vibrator vi;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_alarm);
		
		vi = (Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
		vi.vibrate(new long[]{1000,5000}, 0);
		
		b = (Button)findViewById(R.id.alarm_exit);
		b.setOnClickListener(this);
	}
	public void stop()
	{
		if(vi!=null)
			vi.cancel();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		stop();
	}

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.alarm_exit:
			stop();
			finish();
			break;

		default:
			break;
		}
	}
}
