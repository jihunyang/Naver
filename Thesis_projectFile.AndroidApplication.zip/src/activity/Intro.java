package activity;

import java.util.Timer;
import java.util.TimerTask;

import service.Service_boot;

import yjh.meb.rememberbox.R;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;

public class Intro extends Activity {
	ProgressDialog pd;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_intro);
		startService(new Intent(this,Service_boot.class));
		timeThread();
		
		TimerTask callMain = new TimerTask() {
			@Override
			public void run() {
				Intent intent = new Intent(Intro.this, Main.class);
				startActivity(intent);//main ��Ƽ��Ƽ�� ��ȯ
				finish();//���� ��Ƽ��Ƽ ����
			}
		};

		Timer mTimer = new Timer();
		mTimer.schedule(callMain, 1000);//1000ms �Ŀ� callMain�� run() ȣ��
	}

	public void timeThread() {//���α׷��� ���̾�α� â ����
		pd = new ProgressDialog(this);
		pd.setTitle("�ε����Դϴ�");
		pd.setMessage("Please wait while loading...");
		pd.setIndeterminate(true);
		pd.setCancelable(false);
		pd.show();
		new Thread(new Runnable() {
			public void run() {
				try {
					Thread.sleep(1000); //1000ms�� ���α׷��� ���̾�α� dismiss
				} catch (Throwable ex) {
					ex.printStackTrace();
				}
				pd.dismiss();
			}
		}).start();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		return true;
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if(keyCode == KeyEvent.KEYCODE_BACK)
		{//Ű �̺�Ʈ �޾Ƽ� '�ڷΰ���'�� ��� ����
			return false;
		}
		return super.onKeyDown(keyCode, event);
	}
}
