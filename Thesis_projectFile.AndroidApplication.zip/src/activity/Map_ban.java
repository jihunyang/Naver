package activity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import yjh.meb.rememberbox.R;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Log;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.OverlayItem;
import com.google.android.maps.Projection;

public class Map_ban extends MapActivity {
	private MapView mapView;
	private Geocoder Gc;
	private MapController mapController;
	private double banlat=0, banlng=0;
	float banrange;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_map_ban);		
		Gc = new Geocoder(this, Locale.KOREAN);
		mapView = (MapView) findViewById(R.id.myMap_ban);
		mapView.setBuiltInZoomControls(true);
		mapController = mapView.getController();
		// ��Ŀ �̹��� ����
		
		getBanPoint(); // �����۷������� banpoint ������
		placeMarker(banlat, banlng);
		mapController.animateTo(new GeoPoint((int)(banlat*1E6),(int)(banlng*1E6)));
		mapController.setZoom(17);
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

	@Override
	protected void onPause() {
		super.onPause();
	}

	@Override
	protected boolean isRouteDisplayed() {
		return false;
	}

	public void getBanPoint() {
		SharedPreferences pref = getSharedPreferences(
				"yjh.meb.rememberbox_preferences", MODE_WORLD_READABLE);
		banlat = Double.parseDouble(pref.getString("BAN_LAT", "35.178298"));
		banlng = Double.parseDouble(pref.getString("BAN_LNG", "126.908913"));
		banrange = Float.parseFloat(pref.getString("Location_banrange", "50"));
		Log.d("remember", banlat + "," + banlng + "/" +banrange );
	}
	
	public void placeMarker(double lat, double lng)
	{
		Drawable marker = getResources().getDrawable(R.drawable.marker);
		marker.setBounds(0, 0, marker.getIntrinsicWidth(), marker.getIntrinsicHeight());
		mapView.getOverlays().add(new BanLocation(marker, lat, lng));
	}
	
	public void CenterLocation(GeoPoint centerGeoPoint)
	{
		mapController.animateTo(centerGeoPoint);		
		banlat = (double)centerGeoPoint.getLatitudeE6()/1E6;
		banlng = (double)centerGeoPoint.getLongitudeE6()/1E6;
		placeMarker(banlat, banlng);
	}

	public String parseAddress(GeoPoint gp) {
		StringBuffer juso = new StringBuffer();
		try {
			List<Address> address = Gc.getFromLocation(
					gp.getLatitudeE6() / 1E6, gp.getLongitudeE6() / 1E6, 1);
			for (Address addr : address) {
				int index = addr.getMaxAddressLineIndex();
				for (int i = 0; i <= index; i++) {
					juso.append(addr.getAddressLine(i));
					juso.append(" ");
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return juso.toString();
	}
	
	class BanLocation extends ItemizedOverlay<OverlayItem>{
		private List<OverlayItem> locations = new ArrayList<OverlayItem>();
		private Drawable marker;
		private OverlayItem myOverlayItem;

		public BanLocation(Drawable defaultMarker, double Latitude, double Longitude) {
			super(defaultMarker);
			this.marker = defaultMarker;
			
			GeoPoint myPlace = new GeoPoint((int)(Latitude*1E6), (int)(Longitude*1E6));
			myOverlayItem = new OverlayItem(myPlace, "My Place", "My Place");
			locations.add(myOverlayItem);
			populate();
		}

		@Override
		protected OverlayItem createItem(int i) {
			// TODO Auto-generated method stub
			return locations.get(i);
		}

		@Override
		public int size() {
			// TODO Auto-generated method stub
			return locations.size();
		}

		@Override
		public void draw(Canvas canvas, MapView mapView, boolean shadow) {
			// TODO Auto-generated method stub
			super.draw(canvas, mapView, shadow);
			boundCenterBottom(marker);
			
			Paint circle = new Paint();
			circle.setARGB(255, 0, 0, 255);
			circle.setAlpha(30);

			GeoPoint gp = new GeoPoint((int) (banlat * 1E6), (int) (banlng * 1E6));
			Point geopix = new Point();
			Projection pj = mapView.getProjection();

			pj.toPixels(gp, geopix);
			float radius = pj.metersToEquatorPixels(banrange);
			canvas.drawCircle(geopix.x, geopix.y, radius, circle);
		}
		
		@Override
		public boolean onTap(GeoPoint p, MapView mapView) {			
			SharedPreferences pref = getSharedPreferences("yjh.meb.rememberbox_preferences", MODE_WORLD_READABLE);
			SharedPreferences.Editor edit = pref.edit();
			edit.putString("BAN_LAT", String.valueOf(p.getLatitudeE6()/1E6));
			edit.putString("BAN_LNG", String.valueOf(p.getLongitudeE6()/1E6));
			edit.commit();
			mapView.getOverlays().remove(0);
			CenterLocation(p);
			return true;
		}
		
	}
}
