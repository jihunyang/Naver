package activity;

import java.util.ArrayList;
import java.util.List;


import values.LocationVALUE;
import yjh.meb.rememberbox.R;
import yjh.meb.rememberbox.R.drawable;
import yjh.meb.rememberbox.R.id;
import yjh.meb.rememberbox.R.layout;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.location.Geocoder;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

import dbmanager.DBManager_Location;

public class Map_one extends com.google.android.maps.MapActivity{
	MapView mapView;
	MapController controller;
	
	Drawable drawable;
	List<Overlay> mapOverlays;
	ArrayList<LocationVALUE> locarray;
	MyItemizedOverlay itemizedOverlay;
	OverlayItem overlayItem;
	
	GeoPoint point;	
	DBManager_Location dbm;
	Cursor cursor;
	
	
	public void onCreate(Bundle savedInstancesState) {
		super.onCreate(savedInstancesState);
		setContentView(R.layout.activity_map_one);
		
		Intent in = getIntent();
		int lat = (int)(in.getExtras().getDouble("lat")*1E6);
		int lng = (int)(in.getExtras().getDouble("lng")*1E6);
		String address = in.getExtras().getString("address");
		String time = in.getExtras().getString("time");
		
		
		mapView = (MapView) findViewById(R.id.myMap_one);
		mapView.setBuiltInZoomControls(true);		
		mapView.setSatellite(false);
		
		controller = mapView.getController();		
		mapOverlays = mapView.getOverlays();
		
		drawable = getResources().getDrawable(R.drawable.pin);
		itemizedOverlay = new MyItemizedOverlay(drawable, mapView);
		
		point = new GeoPoint(lat, lng);
		overlayItem = new OverlayItem(point, time, address);
		itemizedOverlay.addOverlay(overlayItem);
		mapOverlays.add(itemizedOverlay);
		
		controller.animateTo(point);
		controller.setZoom(18);		
		
	}

	protected boolean isRouteDisplayed() {
		return false;
	}
}
