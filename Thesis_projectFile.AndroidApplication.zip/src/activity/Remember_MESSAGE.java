package activity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import dbadapter.DBAdapter_Location;
import dbadapter.DBAdapter_Message;
import dbmanager.DBManager_Location;
import dbmanager.DBManager_Message;

import values.LocationVALUE;
import values.MessageVALUE;
import yjh.meb.rememberbox.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;

public class Remember_MESSAGE extends Activity implements OnItemClickListener, OnItemLongClickListener{
	DBManager_Message dManager;
	Cursor cursor;
	DBAdapter_Message dbAdapter_Message;
	ArrayList<MessageVALUE> messagevaluelist;
	
	ListView list;
	TextView incommingnumberstr;
	TextView bodystr;
	TextView timestampstr;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.remember_message);
		
		list = (ListView) findViewById(R.id.listmessage); // ����Ʈ�� ã�Ƽ� ����
		list.setOnItemClickListener(this);
		list.setOnItemLongClickListener(this);
		dManager = new DBManager_Message(this);
		dManager.open();
		getDB(); // DB�� �����ϰ� �� ������
	}
	
	protected void onDestroy() {
		cursor.close();
		dManager.close();
		super.onDestroy();
	}
	
	public boolean onCreateOptionsMenu(Menu menu) {
		menu.add(1,1,1,"��� ����");
		return super.onCreateOptionsMenu(menu);
	}
	public boolean onOptionsItemSelected(MenuItem item) {
		switch(item.getItemId())
		{
		case 1:
			removeDB();
			cursor.requery();
			break;
		}
		return super.onOptionsItemSelected(item);
	}
	
	public void removeDB()
	{
		AlertDialog.Builder gsDialog = new AlertDialog.Builder(this);
		gsDialog.setTitle("���� Ȯ��");
		gsDialog.setMessage("SMS�α׸� ��� �����Ͻðڽ��ϱ�?");
		gsDialog.setPositiveButton("Ȯ��", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				if (dManager.deleteAllValue()) {
					cursor.requery();
					Toast.makeText(getApplicationContext(), "�����Ǿ����ϴ�", Toast.LENGTH_SHORT).show();
				} else
					Toast.makeText(getApplicationContext(), "���� ����", Toast.LENGTH_SHORT).show();
			}
		}).create(); // Ȯ�ι�ư ����
		gsDialog.setNegativeButton("���", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int which) {
				Toast.makeText(getApplicationContext(), "����ϼ̽��ϴ�.", Toast.LENGTH_SHORT).show();
			}
		}).create().show();// ��ҹ�ư �����ϰ� ȭ�鿡 ���
	}
	
	public void getDB() {
		messagevaluelist = new ArrayList<MessageVALUE>(); //��� ����Ʈ ����

		cursor = null;
		cursor = dManager.fetchAllValues();

		if (cursor.getCount() > 0) {
			startManagingCursor(cursor);
			dbAdapter_Message = new DBAdapter_Message(this, cursor);
			list.setAdapter(dbAdapter_Message);
			while(cursor.moveToNext())
			{
				String number = cursor.getString(cursor.getColumnIndex("number"));
				String sr = cursor.getString(cursor.getColumnIndex("sr"));
				String body = cursor.getString(cursor.getColumnIndex("body"));
				String timestamp = cursor.getString(cursor.getColumnIndex("timestamp"));
				
				MessageVALUE m = new MessageVALUE(number, sr, body, timestamp);
				messagevaluelist.add(m);
			}			
		}
	}
	
	public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int arg2,
			long arg3) {
		// TODO Auto-generated method stub
		return false;
	}
	public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
		// TODO Auto-generated method stub
		
	}
	

}
