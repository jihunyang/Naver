package dbmanager;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.UserDictionary.Words;
import android.util.Log;

public class DBManager_Message {
	
	private static final String KEY_INCOMMING_NUMBER = "number";
	private static final String KEY_BODY = "body";
	private static final String KEY_TIMESTAMP = "timestamp";
	private static final String KEY_SENDRECEIVE = "sr";
	private static final String KEY_ROWID = "_id";
	
	private static final String DATABASE_NAME = "MESSAGE.db";
	private static final String DATABASE_TABLE = "message";
	private static final int DATABASE_VERSION = 1;
	
	private final Context mCtx;
	
	private DatabaseHelper mDbHelper;
	private SQLiteDatabase mDb;
	
	private static final String DATABASE_CREATE = "CREATE TABLE message(_id INTEGER PRIMARY KEY AUTOINCREMENT, number TEXT, sr TEXT, body TEXT, timestamp TEXT);";
	
	private static class DatabaseHelper extends SQLiteOpenHelper {
		DatabaseHelper(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

		public void onCreate(SQLiteDatabase db) {
			db.execSQL(DATABASE_CREATE);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.i("info", "Upgrading database from version " + oldVersion + " to "
                    + newVersion + ", which will destroy all old data");
            db.execSQL("drop table if exists message");
            onCreate(db);
        }
	}

	public DBManager_Message(Context ctx) {
		this.mCtx = ctx;
	}	
	public DBManager_Message open() throws SQLException{
		mDbHelper = new DatabaseHelper(mCtx);
        mDb = mDbHelper.getWritableDatabase();
        return this;
	}
	public void close(){
		mDbHelper.close();
	}

	public long createValue(String incomming_number, String sr, String body,String timestamp) {
		SharedPreferences pf = mCtx.getSharedPreferences("yjh.meb.rememberbox_preferences", DATABASE_VERSION);
		boolean shouldwrite = pf.getBoolean("MESSAGE_use", false);
		Log.d("remember","db creatValue����"+shouldwrite);
		if(shouldwrite){
		ContentValues initialValues = new ContentValues();
		initialValues.put(KEY_INCOMMING_NUMBER, incomming_number);
		initialValues.put(KEY_SENDRECEIVE, sr);
		initialValues.put(KEY_BODY, body);
		initialValues.put(KEY_TIMESTAMP, timestamp);
		return mDb.insert(DATABASE_TABLE, null, initialValues);
		}
		else
			return -1;
		
	}

	public boolean deleteValue(long rowId) {
		return mDb.delete(DATABASE_TABLE, KEY_ROWID + "=" + rowId, null)>0;
	}
	public boolean deleteAllValue(){
		return mDb.delete(DATABASE_TABLE, null, null)>0;
	}
	public Cursor fetchAllValues()
	{
		return mDb.query(DATABASE_TABLE,
				new String[] {KEY_ROWID, KEY_INCOMMING_NUMBER, KEY_SENDRECEIVE, KEY_BODY, KEY_TIMESTAMP},
				null, null, null, null, null);
	}
	public Cursor searchValue(long rowId) throws SQLException
	{
		Cursor mCursor = mDb.query(true, DATABASE_TABLE,
				new String[] {KEY_ROWID, KEY_INCOMMING_NUMBER, KEY_SENDRECEIVE, KEY_BODY, KEY_TIMESTAMP},
				KEY_ROWID + "=" + rowId,null, null, null, null, null);
		        if (mCursor != null) {
		            mCursor.moveToFirst();
		        }
		        return mCursor;
	}
}

//drop table if exists GPS
