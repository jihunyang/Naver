package values;

import java.io.Serializable;

public class MessageVALUE implements Serializable {
	private String number;
	private String body;
	private String timestamp;
	private String sr;

	public MessageVALUE(String number, String sr, String body, String timestamp) {
		super();
		this.number = number;
		this.body = body;
		this.timestamp = timestamp;
		this.sr = sr;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getSr() {
		return sr;
	}

	public void setSr(String sr) {
		this.sr = sr;
	}
}
