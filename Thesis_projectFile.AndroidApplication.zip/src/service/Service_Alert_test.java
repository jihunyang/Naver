package service;

import java.io.File;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;

import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.util.Log;
import broadcasereceiver.ReceiverLocation;

public class Service_Alert_test extends Service implements LocationListener{
	private LocationManager locationManager;	
	private Location location;
	private double banlat, banlng;
	private float banrange;		
	private ReceiverLocation receiver;
	PendingIntent pi;
	String TAG = "remember";	
	
	public void onCreate() {
		super.onCreate();
		getPreference(); // ����, �浵, �ݰ� ��������
		locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
		LOGG(TAG,"�˸����� onCreate()");
	}

	public void onStart(Intent intent, int startId) {
		super.onStart(intent, startId);
		
		locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 0, 0, this);
		receiver = new ReceiverLocation();
        Intent it = new Intent(this, ReceiverLocation.class);
		pi = PendingIntent.getBroadcast(this, 0, it, 0);
		locationManager.addProximityAlert(banlat, banlng, banrange, -1, pi);
		
        LOGG(TAG,"�˸����� onStart()");
	}
	
	public void onDestroy() {
		locationManager.removeUpdates(this);
		super.onDestroy();
		LOGG(TAG,"�˸����� onDestroy()");
	}
	
	public void getPreference() {
		SharedPreferences pref = getSharedPreferences(
				"yjh.meb.rememberbox_preferences", MODE_WORLD_READABLE);
		banrange = Float.parseFloat(pref.getString("Location_banrange", "100"));
		banlat = Double.parseDouble(pref.getString("BAN_LAT", "35.178298"));
		banlng = Double.parseDouble(pref.getString("BAN_LNG", "126.908913"));
	}
	public IBinder onBind(Intent intent) {return null;}
	public void onLocationChanged(Location location) { this.location = location; }
	public void onProviderDisabled(String provider) {	}
	public void onProviderEnabled(String provider) {	}
	public void onStatusChanged(String provider, int status, Bundle extras) {	}

	public void LOGG(String tag, String body)
    {
    	Log.d("remember", body);
    	String dir_path = getFilesDir().getAbsolutePath();
    	String file_path = dir_path + "/log.txt";
    	File f = new File(dir_path);
    	if(!f.exists())
    	{
    		f.mkdirs();
    	}
    	try{
    		RandomAccessFile raf = new RandomAccessFile(file_path, "rw");
    		raf.seek(raf.length());
    		SimpleDateFormat sd = new SimpleDateFormat(
    				"yy'/'MM'/'dd'.'HH':'mm':'ss");
    		String now = sd.format(System.currentTimeMillis()) + " :: ";
    		raf.write(now.getBytes());
    		raf.write(body.getBytes());
    		raf.write("\n".getBytes());
    		raf.close();
    	}catch(Exception e)
    	{}
    }
}
