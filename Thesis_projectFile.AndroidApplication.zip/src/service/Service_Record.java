package service;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import yjh.meb.rememberbox.R;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaRecorder;
import android.os.Environment;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

public class Service_Record extends Service implements MediaRecorder.OnInfoListener, MediaRecorder.OnErrorListener{

	private static final String TAG = "CallRecorder";
	public static final String DEFAULT_STORAGE_LOCATION = "/sdcard/RememberBox";
	private static final int RECORDING_NOTIFICATION_ID = 1;

	private MediaRecorder recorder = null;
	private boolean isRecording = false;
	private File recording = null;;
	
	private Calendar cal = Calendar.getInstance();

	private String dateToString , timeToString ;
	
	public void onCreate() {
		super.onCreate();
		recorder = new MediaRecorder();
		LOGG("remember", "�������� creat");
	}

	public void onStart(Intent intent, int startId) {

		if (isRecording)
			return;		
		
		Context c = getApplicationContext();
		SharedPreferences pref = getSharedPreferences("yjh.meb.rememberbox_preferences", MODE_WORLD_READABLE);

		Boolean shouldRecord = pref.getBoolean("CALL_use", false);//��ȭ���� ��뿡 üũ�� �Ǿ��ִ���
		if (!shouldRecord) {
			LOGG("remember","��������");
			return;
		}

		int audiosource = Integer.parseInt(pref.getString("AUDIO_SOURCE", "1"));
		int audioformat = Integer.parseInt(pref.getString("AUDIO_FORMAT", "1"));

		recording = makeOutputFile();// ������ ������ ������ ���� ����
		if (recording == null) {
			recorder = null;
			return; // return 0;
		}

		LOGG("remember", "���� ���� ������ҽ� : " + audiosource + " ��������� : "
				+ audioformat);
		try {
			// These calls will throw exceptions unless you set the
			// android.permission.RECORD_AUDIO permission for your app
			recorder.reset();
			recorder.setAudioSource(audiosource);
			LOGG("remember", "����� �ҽ� " + audiosource);
			recorder.setOutputFormat(audioformat);
			LOGG("remember", "�ƿ�ǲ " + audioformat);
			recorder.setAudioEncoder(MediaRecorder.AudioEncoder.DEFAULT);
			LOGG("remember", "���ڵ� ����Ʈ");
			recorder.setOutputFile(recording.getPath());
			LOGG("remember", "�ƿ�ǲ ���� ��ġ: " + recording);

			recorder.setOnInfoListener(this);
			recorder.setOnErrorListener(this);

			try {
				recorder.prepare();
			} catch (java.io.IOException e) {
				Log.e("remember",
						"recorder.prepare() IOException �߻��̿�\n");
				Toast t = Toast.makeText(getApplicationContext(),
						"������ ���� ���� �Ұ�: " + e,
						Toast.LENGTH_LONG);
				t.show();
				recorder = null;
				return; // return 0; //START_STICKY;
			}
			LOGG("CallRecorder", "recorder.prepare() ���ڵ� �غ� �Ϸ�");

			recorder.start();
			isRecording = true;
			Log.i("CallRecorder", "recorder.start() ���ڵ� ������");
			updateNotification(true);
		} catch (java.lang.Exception e) {
			Toast t = Toast.makeText(getApplicationContext(),
					"��ȭ ������ ���� �Ұ��� : " + e,
					Toast.LENGTH_LONG);
			t.show();

			Log.e("remember", "RecordService::onStart �˼� ���� ����", e);
			recorder = null;
		}

		return; // return 0; //return START_STICKY;
	}
	
	public void onDestroy() {
		super.onDestroy();

		if (null != recorder) {
			LOGG("remember",
					"���ڴ� ��Ʈ����");
			isRecording = false;
			recorder.release();
			Toast t = Toast.makeText(getApplicationContext(),
					"CallRecorder finished recording call to " + recording,
					Toast.LENGTH_LONG);
			t.show();
		}
		updateNotification(false);
	}
	
	public IBinder onBind(Intent arg0) {
		return null;
	}

	public void onError(MediaRecorder mr, int what, int extra) {
		Log.e("remember",
				"RecordService got MediaRecorder onError callback with what: "
						+ what + " extra: " + extra);
		isRecording = false;
		mr.release();
	}

	public void onInfo(MediaRecorder mr, int what, int extra) {
		Log.i("remember",
				"RecordService got MediaRecorder onInfo callback with what: "
						+ what + " extra: " + extra);
		isRecording = false;
	}

	private File makeOutputFile() {
		File dir = new File(DEFAULT_STORAGE_LOCATION);

		if (!dir.exists()) {// ���丮�� ���ٸ� �����ϰԲ�
			try {
				dir.mkdirs();
			} catch (Exception e) {
				Log.e("remember", "RecordService::makeOutputFile ���丮 �����Ұ��� : "
						+ dir + ": " + e);
				Toast t = Toast.makeText(getApplicationContext(),
						"������ġ ���� �Ұ��� " + dir + " ����: " + e, Toast.LENGTH_LONG);
				t.show();
				return null;
			}
		} else {
			if (!dir.canWrite()) {// ���丮�� ���� ���ٸ�
				Log.e(TAG, "RecordService::makeOutputFile ���� ���� ����: " + dir);
				Toast t = Toast.makeText(getApplicationContext(),
						"CallRecorder does not have write permission for the directory directory "
								+ dir + " to store recordings",
						Toast.LENGTH_LONG);
				t.show();
				return null;
			}
		}
		dateToString = String.format("%d��%d��", cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH));
		timeToString = String.format("%d��%d��", cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE));
		// create filename based on call data
		String prefix = dateToString + " " + timeToString;
		SharedPreferences pref = getSharedPreferences("yjh.meb.rememberbox_preferences", MODE_WORLD_READABLE);
		
		// create suffix based on format
		String suffix = "";
		int audioformat = Integer.parseInt(pref.getString("AUDIO_FORMAT", "1"));
		switch (audioformat) {
		case MediaRecorder.OutputFormat.THREE_GPP:
			suffix = ".3gpp";
			break;
		case MediaRecorder.OutputFormat.MPEG_4:
			suffix = ".mpg";
			break;
		case MediaRecorder.OutputFormat.RAW_AMR:
			suffix = ".amr";
			break;
		}

		try {
			return new File(dir + "/" + prefix + suffix);
		} catch (Exception e) {
			Log.e("remember", "RecordService::makeOutputFile �������� ���� �Ұ��� ��ġ: "
					+ dir + ": " + e);
			Toast t = Toast.makeText(getApplicationContext(),
					"CallRecorder was unable to create temp file in " + dir
							+ ": " + e, Toast.LENGTH_LONG);
			t.show();
			return null;
		}
	}

	private void updateNotification(Boolean status) {//�˸��� ���ϰ� ����
		Context c = getApplicationContext();
		SharedPreferences pref = getSharedPreferences("yjh.meb.rememberbox_preferences", MODE_WORLD_READABLE);

		String ns = Context.NOTIFICATION_SERVICE;
		NotificationManager mNotificationManager = (NotificationManager) getSystemService(ns);

		if (status) {
			int icon = R.drawable.rec_icon;
			CharSequence tickerText = "������ ä�� : "
					+ pref.getString("AUDIO_SOURCE", "1");
			long when = System.currentTimeMillis();

			Notification notification = new Notification(icon, tickerText, when);

			Context context = getApplicationContext();
			CharSequence contentTitle = "���� ����";
			CharSequence contentText = "��ȭ ������ �Դϴ�...";
			Intent notificationIntent = new Intent(this, Service_Record.class);
			PendingIntent contentIntent = PendingIntent.getActivity(this, 0,
					notificationIntent, 0);

			notification.setLatestEventInfo(context, contentTitle, contentText,
					contentIntent);
			mNotificationManager
					.notify(RECORDING_NOTIFICATION_ID, notification);
		} else {
			mNotificationManager.cancel(RECORDING_NOTIFICATION_ID);
		}
	}
	public void LOGG(String tag, String body)
    {
    	Log.d("remember", body);
    	String dir_path = getFilesDir().getAbsolutePath();
    	String file_path = dir_path + "/log.txt";
    	File f = new File(dir_path);
    	if(!f.exists())
    	{
    		f.mkdirs();
    	}
    	try{
    		RandomAccessFile raf = new RandomAccessFile(file_path, "rw");
    		raf.seek(raf.length());
    		SimpleDateFormat sd = new SimpleDateFormat(
    				"yy'/'MM'/'dd'.'HH':'mm':'ss");
    		String now = sd.format(System.currentTimeMillis()) + " :: ";
    		raf.write(now.getBytes());
    		raf.write(body.getBytes());
    		raf.write("\n".getBytes());
    		raf.close();
    	}catch(Exception e)
    	{}
    }
}
