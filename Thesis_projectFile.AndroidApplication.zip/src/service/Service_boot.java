package service;

import java.io.File;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;
import java.util.List;

import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.IBinder;
import android.util.Log;

public class Service_boot extends Service{

	SharedPreferences pref;
	boolean ischecked_location;
	boolean ischecked_ban;
	boolean ischecked_message;
	String TAG = "remember";
	
	
	public void onCreate() {
		super.onCreate();
	}

	public void onStart(Intent intent, int startId) {
		super.onStart(intent, startId);
		LOGG(TAG,"���� ��Ʈ onStart() �۵�");
		pref = getSharedPreferences("yjh.meb.rememberbox_preferences", MODE_WORLD_READABLE);
		ischecked_location = pref.getBoolean("Location_use", false);
		ischecked_ban = pref.getBoolean("Location_bannotice", false);
		ischecked_message = pref.getBoolean("MESSAGE_use", false);
		LOGG(TAG, "��ġ��� : " + ischecked_location + "/�˸�������� : " + ischecked_ban + "/�޽������ : "+ischecked_message);
		
		if(ischecked_location)
		{
			if (!isRunningService("Service_LOC")) {
				AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
				Intent i = new Intent("yjh.meb.Location");
				PendingIntent pi = PendingIntent.getService(this, 0, i, 0);
				am.setRepeating(AlarmManager.RTC, System.currentTimeMillis(),
						getTimming(), pi);
				LOGG(TAG, "Service_boot�� ��ġ���� ����");
			}
			else
				LOGG(TAG,"��ġ�������� �̹� ���۵�");
		}
		if(ischecked_ban)
		{
			if(!isRunningClass("Service_Alert_test"))
			{
				startService(new Intent(this, Service_Alert_test.class));
				LOGG(TAG, "Service_boot�� �˸����� ����");
			}
			else
				LOGG(TAG, "�˸����� �̹� ���۵�");
		}
		if(ischecked_message)
		{
			if(!isRunningClass("Service_Message"))
			{
				startService(new Intent(this, Service_Message.class));
				LOGG(TAG, "Service_boot�� �޽��� �α� ����");
			}
			else
				LOGG(TAG,"�޽����α� �̹� ���۵�");
		}
		stopSelf();
		LOGG(TAG, "���� ��Ʈ onStart()���� stopSelf()ȣ��");
	}

	public int getTimming()
	{
		SharedPreferences pref = getSharedPreferences(
				"yjh.meb.rememberbox_preferences", MODE_WORLD_READABLE);
		int temp = Integer.parseInt(pref.getString("Location_checktime", "5"))*1000 * 60;
		return temp;
	}
	
	public IBinder onBind(Intent intent) {return null;}
	
	public boolean isRunningService(String name){
		ActivityManager ac = (ActivityManager)getSystemService(ACTIVITY_SERVICE);
		List<ActivityManager.RunningServiceInfo> rs = ac.getRunningServices(Integer.MAX_VALUE);
		boolean serviceAlive = false;
		for (ActivityManager.RunningServiceInfo runningServiceInfo : rs) {
			if(runningServiceInfo.service.toString().contains(name))
			{
				serviceAlive = true;
			}
		}
		return  serviceAlive;
	}
	public boolean isRunningClass(String name){
		ActivityManager ac = (ActivityManager)getSystemService(ACTIVITY_SERVICE);
		List<ActivityManager.RunningServiceInfo> rs = ac.getRunningServices(Integer.MAX_VALUE);
		boolean serviceAlive = false;
		for (ActivityManager.RunningServiceInfo runningServiceInfo : rs) {
			if(runningServiceInfo.service.getClassName().toString().contains(name))
			{
				serviceAlive = true;
			}
		}
		return  serviceAlive;
	}
	
	public void LOGG(String tag, String body)
    {
    	Log.d("remember", body);
    	String dir_path = getFilesDir().getAbsolutePath();
    	String file_path = dir_path + "/boot_log.txt";
    	File f = new File(dir_path);
    	if(!f.exists())
    	{
    		f.mkdirs();
    	}
    	try{
    		RandomAccessFile raf = new RandomAccessFile(file_path, "rw");
    		raf.seek(raf.length());
    		SimpleDateFormat sd = new SimpleDateFormat(
    				"yy'/'MM'/'dd'.'HH':'mm':'ss");
    		String now = sd.format(System.currentTimeMillis()) + " :: ";
    		raf.write(now.getBytes());
    		raf.write(body.getBytes());
    		raf.write("\n".getBytes());
    		raf.close();
    	}catch(Exception e)
    	{}
    }

}
