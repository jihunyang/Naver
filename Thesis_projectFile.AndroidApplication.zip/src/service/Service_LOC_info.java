package service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import yjh.meb.rememberbox.R;

import com.google.android.maps.MapView;
import com.google.android.maps.MyLocationOverlay;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.IBinder;
import android.util.AttributeSet;
import android.util.Log;
import dbmanager.DBManager_Location;

public class Service_LOC_info extends Service {

	static String TAG = "remember";
	Context mcontext;
	private static Location location_now = null;
	//private String provider;
	private Geocoder geoCoder;
	private DBManager_Location dManager;

	private double latPoint = 0;
	private double lngPoint = 0;
	private String address = "";// �ּҰ���
	private String timestr = "";// �ε��ѽð�
	
	Timer timer1 = null;
    LocationManager lm;
    
    boolean gps_enabled=false;
    boolean network_enabled=false;

	public void onCreate() {
		super.onCreate();		
		mcontext = getApplicationContext();
		geoCoder = new Geocoder(mcontext, Locale.KOREAN);
		dManager = new DBManager_Location(mcontext);
		LOGG(TAG, "Service_LOC_info�� onCreat()ȣ��");
	}	

	@Override
	public void onStart(Intent intent, int startId) {
		super.onStart(intent, startId);
		LOGG(TAG, "Service_LOC_info�� onStart() ȣ��");	
		
		requestupdateLocation();
		timer1 = new Timer();
		timer1.schedule(new GetLastLocation(), 10 * 1000);//30�� ��ٷǴٰ� GetLast~~����
		updateLocation();
		LOGG(TAG, "������ ����");
	}

	public void onDestroy() {
		try{dManager.close();}catch(Exception e){}
		lm.removeUpdates(locationListenerNetwork);
		lm.removeUpdates(locationListenerGps);
		LOGG("remember", "�����ִ� ������ ����" + timer1.purge());
		timer1.cancel();		
		super.onDestroy();
		//Toast.makeText(getApplicationContext(), "��ġ���� destroy", Toast.LENGTH_SHORT).show();
		LOGG(TAG, "��ġ���� ���� destroy");
	}
	
	public IBinder onBind(Intent intent) {
		return null;
	}
	
	public void requestupdateLocation()
	{
		if(lm==null)
            lm = (LocationManager) mcontext.getSystemService(Context.LOCATION_SERVICE);

        //exceptions will be thrown if provider is not permitted.
        try{gps_enabled=lm.isProviderEnabled(LocationManager.GPS_PROVIDER);}catch(Exception ex){}
        try{network_enabled=lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER);}catch(Exception ex){}

        if(!gps_enabled && !network_enabled)
        	return;
        
        if (gps_enabled)
			lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0,
					locationListenerGps);
		if (network_enabled)
			lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 20000, 0,
					locationListenerNetwork);		
	}
	
	LocationListener locationListenerGps = new LocationListener() {
        public void onLocationChanged(Location location) {
        	LOGG(TAG,"gps������ ä����");
        	//timer1.cancel();
        	location_now = location;
        	lm.removeUpdates(this);
        }
        public void onProviderDisabled(String provider) {}
        public void onProviderEnabled(String provider) {}
        public void onStatusChanged(String provider, int status, Bundle extras) {}
    };

    LocationListener locationListenerNetwork = new LocationListener() {
        public void onLocationChanged(Location location) {
        	LOGG(TAG,"��Ʈ��ũ������ä����");
        	timer1.cancel();
        	location_now = location;
        	lm.removeUpdates(this);
        }
        public void onProviderDisabled(String provider) {}
        public void onProviderEnabled(String provider) {}
        public void onStatusChanged(String provider, int status, Bundle extras) {}
    };
    
    class GetLastLocation extends TimerTask {
        @Override
		public void run() {
        	LOGG("remember", "GetLastLocation extends TimerTask ȣ��");
			lm.removeUpdates(locationListenerGps);
			lm.removeUpdates(locationListenerNetwork);

			Location net_loc = null, gps_loc = null;
			if (gps_enabled)
				gps_loc = lm
						.getLastKnownLocation(LocationManager.GPS_PROVIDER);
			if (network_enabled)
				net_loc = lm
						.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);

			// if there are both values use the latest one
			if (gps_loc != null && net_loc != null) {
				if (gps_loc.getTime() > net_loc.getTime()){
					location_now = gps_loc;
				}
				else if(net_loc.getTime()-gps_loc.getTime()<15000 && (gps_loc.getAccuracy()<net_loc.getAccuracy())){
					location_now = gps_loc;
				}else{
					location_now = net_loc;
				}
				return;
			}

			if (gps_loc != null) {
				location_now = gps_loc;
				return;
			}
			if (net_loc != null) {
				location_now = net_loc;
				return;
			}
			insertNoninfo();
        }
	}
    
    public void insertNoninfo()
    {
    	LOGG("remember", "insertNoninfo()ȣ��");
    	dManager.open();
    	dManager.createValue(0, 0, "��Ȯ�� ��ġ�� �ƴմϴ�", "x", parseDate(System.currentTimeMillis()));
    	dManager.close();
    }
	
    public void updateLocation() {
		LOGG(TAG,"updateLocation() db�� ����");    		
		// �ּ� ��������
		StringBuffer juso = new StringBuffer();
		if (location_now != null) {
			latPoint = location_now.getLatitude();
			lngPoint = location_now.getLongitude();
			String provider = location_now.getProvider();
			try {
				// ����,�浵�� �̿��Ͽ� ���� ��ġ�� �ּҸ� �����´�.
				List<Address> addresses;
				addresses = geoCoder.getFromLocation(latPoint, lngPoint, 1);
				for (Address addr : addresses) {
					int index = addr.getMaxAddressLineIndex();
					for (int i = 0; i <= index; i++) {
						juso.append(addr.getAddressLine(i));
						juso.append(" ");
					}
				}
			} catch (IOException e) {}
			timestr = parseDate(System.currentTimeMillis());
			address = String.valueOf(juso);
			dManager.open();
			dManager.createValue(latPoint, lngPoint, address, provider, timestr);
			dManager.close();
			String temp = latPoint + "," + lngPoint + "//" + address + "//" + provider + "//" + timestr; 
			LOGG(TAG, temp + "//"+parseDate(location_now.getTime()));
		} else{
			//insertNoninfo();
			LOGG(TAG,"location_now�� null�̿���");
		}
	}
    
    public void LOGG(String tag, String body)
    {
    	Log.d("remember", body);
    	String dir_path = getFilesDir().getAbsolutePath();
    	String file_path = dir_path + "/log.txt";
    	File f = new File(dir_path);
    	if(!f.exists())
    	{
    		f.mkdirs();
    	}
    	try{
    		RandomAccessFile raf = new RandomAccessFile(file_path, "rw");
    		raf.seek(raf.length());
    		SimpleDateFormat sd = new SimpleDateFormat(
    				"yy'/'MM'/'dd'.'HH':'mm':'ss");
    		String now = sd.format(System.currentTimeMillis()) + " :: ";
    		raf.write(now.getBytes());
    		raf.write(body.getBytes());
    		raf.write("\n".getBytes());
    		raf.close();
    	}catch(Exception e)
    	{}
    }

	public String parseDate(long time) {
		SimpleDateFormat sdf = new SimpleDateFormat(
				"yyyy'/'MM'/'dd'. 'HH':'mm':'ss");
		Date dd = new Date(time);
		return sdf.format(dd);
	}
}