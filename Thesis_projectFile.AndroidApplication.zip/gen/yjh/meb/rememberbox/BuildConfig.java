/** Automatically generated file. DO NOT MODIFY */
package yjh.meb.rememberbox;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}