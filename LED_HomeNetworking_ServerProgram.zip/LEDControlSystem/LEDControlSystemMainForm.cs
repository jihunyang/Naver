﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
using System.Collections;
using System.Threading;
using System.Net;
using System.Net.Sockets;

namespace LEDControlSystem
{
    public partial class LEDControlSystemMainForm : Form
    {
        public static Socket Server, AcceptClient;
        public static Thread socket_thread = null;
        //위에꺼는 소켓
        string[] portArray;
        DataList newsArray;
        DataList cookArray;
        DataList weatherArray;
        ParseNews parseNews;
        ParseCook parseCook;
        ParseWeather parseWeather;
        String day;
        String weather;
        //Thread thread;
        bool changingPassword;
        string[] password;
        int passIndex;

        public LEDControlSystemMainForm()
        {
            InitializeComponent();

            parseNews = new ParseNews();
            parseCook = new ParseCook();
            parseWeather = new ParseWeather();

            setPortListToComboBox();
            setSerialPort();
            setNewsTextBox();
            setCookTextBox();
            setTestTextBox();
            setWeatherTextBox();

            changingPassword = false;
            password = new string[8];
            passIndex = 0;
            socketip.Text = getIP();
        }
        private void setWeatherTextBox()
        {
            weatherTextBox.Clear();
            parseWeather.parse();
            weatherArray = parseWeather.getDataList();
            if (weatherArray.Count != 0)
            {
                weather = weatherArray[0].Title;
                day = weatherArray[1].Title;
                setweatherstring();
                setdaystring();
                SelectDayWeather();
                weatherTextBox.Text = day + " " + weather;
            }
        }
        private void SelectDayWeather()
        {
            if (day == "월")
                listBox1.SetSelected(0, true);
            if (day == "화")
                listBox1.SetSelected(1, true);
            if (day == "수")
                listBox1.SetSelected(2, true);
            if (day == "목")
                listBox1.SetSelected(3, true);
            if (day == "금")
                listBox1.SetSelected(4, true);
            if (day == "토")
                listBox1.SetSelected(5, true);
            if (day == "일")
                listBox1.SetSelected(6, true);
            if (weather == "맑음")
                listBox2.SetSelected(0, true);
            if (weather == "비")
                listBox2.SetSelected(1, true);
            if (weather == "구름")
                listBox2.SetSelected(2, true);
            if (weather == "눈")
                listBox2.SetSelected(3, true);

        }
        private void setdaystring()
        {
            char[] a = new char[15];
            a = day.ToCharArray(0, day.Length);
            day = a[6].ToString();
        }
        private void setweatherstring()
        {
            if (weather == "흐림" || weather == "구름조금" || weather == "구름많음")
                weather = "구름";
        }
        private void setNewsTextBox()
        {
            newsTextBox.Clear();
            parseNews.parse();
            newsArray = parseNews.getDataList();
            if (newsArray.Count != 0)
            {
                for (int i = 0; i < 5; i++)
                {
                    newsTextBox.Text += (i + 1) + ". " + newsArray[i].Title + " / ";
                }
            }
        }
        private void setCookTextBox()
        {
            cookTextBox.Clear();
            parseCook.parse();
            cookArray = parseCook.getDataList();
            if (cookArray.Count != 0)
            {
                for (int i = 0; i < cookArray.Count; i++)
                {
                    cookTextBox.Text += cookArray[i].Title;
                }
            }
        }
        private void setTestTextBox()
        {
            testWriteTextBox.Text = "Default Sentence!";
        }
        private void setPortListToComboBox()
        {
            portComboBox1.Items.Clear();
            portComboBox2.Items.Clear();
            portComboBox3.Items.Clear();
            portComboBox4.Items.Clear();
            portComboBox5.Items.Clear();
            portArray = SerialPort.GetPortNames();
            foreach (string portNumber in portArray)
            {
                portComboBox1.Items.Add(portNumber);
                portComboBox2.Items.Add(portNumber);
                portComboBox3.Items.Add(portNumber);
                portComboBox4.Items.Add(portNumber);
                portComboBox5.Items.Add(portNumber);
            }
        }
        private void setSerialPort()
        {
            if (serialNews.IsOpen) serialTest.Close();
            serialNews.BaudRate = 57600;
            serialNews.DataBits = 8;
            serialNews.Parity = Parity.None;
            serialNews.StopBits = StopBits.One;
            serialNews.Handshake = Handshake.None;

            if (serialCook.IsOpen) serialTest.Close();
            serialCook.BaudRate = 57600;
            serialCook.DataBits = 8;
            serialCook.Parity = Parity.None;
            serialCook.StopBits = StopBits.One;
            serialCook.Handshake = Handshake.None;

            if (serialWeather.IsOpen) serialTest.Close();
            serialWeather.BaudRate = 57600;
            serialWeather.DataBits = 8;
            serialWeather.Parity = Parity.None;
            serialWeather.StopBits = StopBits.One;
            serialWeather.Handshake = Handshake.None;

            if (serialTest.IsOpen) serialTest.Close();
            serialTest.BaudRate = 9600;
            serialTest.DataBits = 8;
            serialTest.Parity = Parity.None;
            serialTest.StopBits = StopBits.One;
            serialTest.Handshake = Handshake.None;

            if (serialPassword.IsOpen) serialPassword.Close();
            serialPassword.BaudRate = 57600;
            serialPassword.DataBits = 8;
            serialPassword.Parity = Parity.None;
            serialPassword.StopBits = StopBits.One;
            serialPassword.Handshake = Handshake.None;
        }
        private string getEncodingStringToString(string inputString)
        {
            string sendData = inputString;
            // 코드페이지 번호는 http://msdn.microsoft.com/ko-kr/library/system.text.encoding.aspx 에서 확인 가능
            //int ks5601Codepage = 949;
            System.Text.Encoding UTF8 = System.Text.Encoding.UTF8;
            byte[] utf8Bytes = UTF8.GetBytes(sendData);
            // 인코딩된것을 문자열로 변환하여 전송
            string decodedStringByUTF8 = UTF8.GetString(utf8Bytes);

            return decodedStringByUTF8;
            //serialPort1.Write(decodedStringByKS5601);
            // 인코딩된 것을 바이트배열 형식으로 전송
            //serialTest.Write(ks5601Bytes, 0, ks5601Bytes.Length);
        }
        private byte[] getEncodingStringToByte(string inputString)
        {
            string sendData = inputString + "\0";
            // 코드페이지 번호는 http://msdn.microsoft.com/ko-kr/library/system.text.encoding.aspx 에서 확인 가능
            int ks5601Codepage = 949;
            System.Text.Encoding ks5601 = System.Text.Encoding.GetEncoding(ks5601Codepage);
            byte[] ks5601Bytes = ks5601.GetBytes(sendData);

            return ks5601Bytes;
            // 인코딩된것을 문자열로 변환하여 전송
            //string decodedStringByKS5601 = ks5601.GetString(ks5601Bytes);
            //serialPort1.Write(decodedStringByKS5601);
            // 인코딩된 것을 바이트배열 형식으로 전송
            //serialTest.Write(ks5601Bytes, 0, ks5601Bytes.Length);
        }

        private void connectNewsButton_Click(object sender, EventArgs e)
        {
            if (!portComboBox1.Text.Equals(""))
            {
                if (!serialNews.IsOpen)
                {
                    serialNews.PortName = portComboBox1.Text;
                    serialNews.Open();
                    //MessageBox.Show(portComboBox1.Text + "포트에 연결되었습니다.");
                    indicatorStr1.Text = "-- 연결됨";
                }
            }
            else
            {
                MessageBox.Show("포트번호를 선택하세요.");
            }
        }
        private void disconnectNewsButton_Click(object sender, EventArgs e)
        {
            if (serialNews.IsOpen)
            {
                serialNews.Close();
                // MessageBox.Show("연결해제 하였습니다");
                indicatorStr1.Text = "-- 연결안됨";
                indicatorStr6.Text = "    --";
                indicatorStr11.Text = "    --";
            }
        }
        private void connectCookButton_Click(object sender, EventArgs e)
        {
            if (!portComboBox2.Text.Equals(""))
            {
                if (!serialCook.IsOpen)
                {
                    serialCook.PortName = portComboBox2.Text;
                    serialCook.Open();
                    // MessageBox.Show(portComboBox2.Text + "포트에 연결되었습니다.");
                    indicatorStr2.Text = "-- 연결됨";
                }
            }
            else
            {
                MessageBox.Show("포트번호를 선택하세요.");
            }
        }
        private void disconnectCookButton_Click(object sender, EventArgs e)
        {
            if (serialCook.IsOpen)
            {
                serialCook.Close();
                //MessageBox.Show("연결해제 하였습니다");
                indicatorStr2.Text = "-- 연결안됨";
                indicatorStr7.Text = "    --";
                indicatorStr11.Text = "    --";
            }
        }
        private void connectWeatherButton_Click(object sender, EventArgs e)
        {
            if (!portComboBox3.Text.Equals(""))
            {
                if (!serialWeather.IsOpen)
                {
                    serialWeather.PortName = portComboBox3.Text;
                    serialWeather.Open();
                    //  MessageBox.Show(portComboBox3.Text + "포트에 연결되었습니다.");
                    indicatorStr3.Text = "-- 연결됨";
                }
            }
            else
            {
                MessageBox.Show("포트번호를 선택하세요.");
            }
        }
        private void disconnectWeatherButton_Click(object sender, EventArgs e)
        {
            if (serialWeather.IsOpen)
            {
                serialWeather.Close();
                //MessageBox.Show("연결해제 하였습니다");
                indicatorStr3.Text = "-- 연결안됨";
                indicatorStrDW.Text = "";
                indicatorStr8.Text = "    --";
                indicatorStr12.Text = "    --";
            }
        }
        private void submitWeatherButton_Click(object sender, EventArgs e)
        {
            if (serialWeather.IsOpen)
            {
                byte[] sendData = getDayWeather();
                serialWeather.Write(sendData, 0, sendData.Length);
                serialWeather.Write(sendData, 0, sendData.Length);
                indicatorStrDW.Text = listBox1.Text + ", " + listBox2.Text + " 전송";
                testReadTextBox.Text = String.Format("{0:X}", sendData[0]);
                indicatorStr12.Text = "전송 완료";
            }
            else
            {
                MessageBox.Show("포트번호를 선택하세요");
            }
        }
        private void connectTest_Click(object sender, EventArgs e)
        {
            if (!portComboBox5.Text.Equals(""))
            {
                if (!serialTest.IsOpen)
                {
                    serialTest.PortName = portComboBox5.Text;
                    serialTest.Open();
                    // MessageBox.Show(portComboBox5.Text+"포트에 연결되었습니다.");
                    indicatorStr5.Text = "-- 연결됨";
                }
            }
            else
            {
                MessageBox.Show("포트번호를 선택하세요.");
            }
        }
        private void disconnectTest_Click(object sender, EventArgs e)
        {
            if (serialTest.IsOpen)
            {
                serialTest.Close();
                // MessageBox.Show("연결해제 하였습니다");
                indicatorStr5.Text = "-- 연결안됨";
            }
        }
        private void submitTest_Click(object sender, EventArgs e)
        {
            if (serialTest.IsOpen)
            {
                string tempData = testWriteTextBox.Text;
                byte[] sendData = getEncodingStringToByte(tempData);
                serialTest.Write(sendData, 0, sendData.Length);
                testWriteTextBox.Text = "";
                // MessageBox.Show(tempData+" 전송");
            }
        }
        private void passConnectBtn_Click(object sender, EventArgs e)
        {
            if (!portComboBox4.Text.Equals(""))
            {
                if (!serialPassword.IsOpen)
                {
                    serialPassword.PortName = portComboBox4.Text;
                    serialPassword.Open();
                    changingPassword = false;
                    // MessageBox.Show(portComboBox4.Text + "포트에 연결되었습니다.");
                    indicatorStr4.Text = "-- 연결됨";
                }
            }
            else
            {
                MessageBox.Show("포트번호를 선택하세요.");
            }
        }
        private void passDisconnectBtn_Click(object sender, EventArgs e)
        {
            if (serialPassword.IsOpen)
            {
                serialPassword.Close();
                changingPassword = false;
                // MessageBox.Show("연결해제 하였습니다");
                indicatorStr4.Text = "-- 연결안됨";
            }
        }
        private void refreshNewsButton_Click(object sender, EventArgs e)
        {
            setNewsTextBox();
        }
        private void refreshCookButton_Click(object sender, EventArgs e)
        {
            setCookTextBox();
        }

        private void serialTest_DataReceived(object sender, SerialDataReceivedEventArgs e) //테스트 부분 데이터 받는 이벤트 처리부분.
        {
            try
            {
                string message = string.Format("{0:X}", serialTest.ReadByte());
                testReadTextBox.Text += message + ",";
                if (message.Equals("5"))
                {
                    Thread.Sleep(500);
                    string tempData = testWriteTextBox.Text;
                    byte[] sendData = getEncodingStringToByte(tempData);
                    serialTest.Write(sendData, 0, sendData.Length);
                }

            }
            catch (TimeoutException)
            {
                Console.WriteLine("Serial Port Timeout Exception");
            }
        }
        private void serialNews_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                indicatorStr6.Text = "데이터 받음";
                string message = string.Format("{0:X}", serialNews.ReadByte());
                if (message.Equals("5"))
                {
                    Thread.Sleep(500);
                    string tempData = newsTextBox.Text;
                    byte[] sendData = getEncodingStringToByte(tempData);
                    serialNews.Write(sendData, 0, sendData.Length);
                    indicatorStr10.Text = "전송 완료";
                }
            }
            catch (TimeoutException)
            {
                Console.WriteLine("Serial Port Timeout Exception");
            }
        }
        private void serialCook_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                indicatorStr7.Text = "데이터 받음";
                string message = string.Format("{0:X}", serialCook.ReadByte());
                if (message.Equals("5"))
                {
                    Thread.Sleep(500);
                    string tempData = cookTextBox.Text;
                    byte[] sendData = getEncodingStringToByte(tempData);
                    serialCook.Write(sendData, 0, sendData.Length);
                    indicatorStr11.Text = "전송 완료";
                }

            }
            catch (TimeoutException)
            {
                Console.WriteLine("Serial Port Timeout Exception");
            }
        }
        private void serialWeather_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                string message = string.Format("{0:X}", serialWeather.ReadByte());
                if (message.Equals("2"))
                {
                    indicatorStr8.Text = "데이터 받음";
                    byte[] sendData = getDayWeather();
                    serialWeather.Write(sendData, 0, sendData.Length);
                    serialWeather.Write(sendData, 0, sendData.Length);
                    testReadTextBox.Text = String.Format("{0:X}", sendData[0]);
                    indicatorStr12.Text = "전송 완료";
                }
            }
            catch (TimeoutException)
            {
                Console.WriteLine("Serial Port Timeout Exception");
            }
        }
        private void serialPassword_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                indicatorStr9.Text = "데이터 받음";
                string message = string.Format("{0:X}", serialPassword.ReadByte());

                string path = @"c:\PASSWORD\password.txt";
                //  MessageBox.Show(message);
                if (message.Equals("63") && (changingPassword == true)) //c 암호 변경완료
                {
                    //MessageBox.Show(message);
                    if (passIndex == 8)
                    {
                        if (!File.Exists(path))
                        {
                            using (StreamWriter sw = File.CreateText(path))
                            {
                                for (int i = 0; i < 8; i++)
                                {
                                    sw.Write(int.Parse(password[i]) - 30);
                                }
                            }
                        }
                        else
                        {
                            using (StreamWriter sw = new StreamWriter(path))
                            {
                                for (int i = 0; i < 8; i++)
                                {
                                    sw.Write(int.Parse(password[i]) - 30);
                                }
                            }
                        }
                    }
                    changingPassword = false;
                    passIndex = 0;
                }
                if (changingPassword)
                {
                    password[passIndex] = message;
                    passIndex++;
                }
                if (message.Equals("61") && (changingPassword == false)) // 최초 암호 전송
                {
                    string result = "";

                    if (!File.Exists(path))
                    {
                        using (StreamWriter sw = File.CreateText(path))
                        {
                            for (int i = 0; i < 8; i++)
                            {
                                sw.Write(1);
                            }
                        }
                    }

                    using (StreamReader sr = File.OpenText(path))
                    {
                        string s = "";

                        while ((s = sr.ReadLine()) != null)
                        {
                            result = s;
                            foreach (Char c in s.ToCharArray())
                            {
                                Thread.Sleep(500);

                                // MessageBox.Show(String.Format("{0:X}",s));
                                byte[] sendData = new byte[1];
                                sendData[0] = Convert.ToByte(c);
                                serialPassword.Write(sendData, 0, sendData.Length);
                                //result += "\n";
                            }
                        }
                    }
                }
                if (message.Equals("62") && (changingPassword == false)) //b 암호 변경시.
                {
                    changingPassword = true;
                }
            }
            catch (TimeoutException)
            {
                Console.WriteLine("Serial Port Timeout Exception");
            }
            indicatorStr13.Text = "전송 완료";
        }
        private void testWriteTextBox_MouseDown(object sender, MouseEventArgs e)
        {
            testWriteTextBox.Text = "";
        }

        private byte[] getDayWeather()
        {
            byte[] a = new byte[1];
            if (listBox1.Text.Equals("월요일") && listBox2.Text.Equals("맑음"))
                a[0] = 1;
            else if (listBox1.Text.Equals("월요일") && listBox2.Text.Equals("비"))
                a[0] = 2;
            else if (listBox1.Text.Equals("월요일") && listBox2.Text.Equals("구름"))
                a[0] = 3;
            else if (listBox1.Text.Equals("월요일") && listBox2.Text.Equals("눈"))
                a[0] = 4;
            else if (listBox1.Text.Equals("화요일") && listBox2.Text.Equals("맑음"))
                a[0] = 5;
            else if (listBox1.Text.Equals("화요일") && listBox2.Text.Equals("비"))
                a[0] = 6;
            else if (listBox1.Text.Equals("화요일") && listBox2.Text.Equals("구름"))
                a[0] = 7;
            else if (listBox1.Text.Equals("화요일") && listBox2.Text.Equals("눈"))
                a[0] = 8;
            else if (listBox1.Text.Equals("수요일") && listBox2.Text.Equals("맑음"))
                a[0] = 10;
            else if (listBox1.Text.Equals("수요일") && listBox2.Text.Equals("비"))
                a[0] = 11;
            else if (listBox1.Text.Equals("수요일") && listBox2.Text.Equals("구름"))
                a[0] = 12;
            else if (listBox1.Text.Equals("수요일") && listBox2.Text.Equals("눈"))
                a[0] = 13;
            else if (listBox1.Text.Equals("목요일") && listBox2.Text.Equals("맑음"))
                a[0] = 14;
            else if (listBox1.Text.Equals("목요일") && listBox2.Text.Equals("비"))
                a[0] = 15;
            else if (listBox1.Text.Equals("목요일") && listBox2.Text.Equals("구름"))
                a[0] = 16;
            else if (listBox1.Text.Equals("목요일") && listBox2.Text.Equals("눈"))
                a[0] = 17;
            else if (listBox1.Text.Equals("금요일") && listBox2.Text.Equals("맑음"))
                a[0] = 18;
            else if (listBox1.Text.Equals("금요일") && listBox2.Text.Equals("비"))
                a[0] = 19;
            else if (listBox1.Text.Equals("금요일") && listBox2.Text.Equals("구름"))
                a[0] = 20;
            else if (listBox1.Text.Equals("금요일") && listBox2.Text.Equals("눈"))
                a[0] = 21;
            else if (listBox1.Text.Equals("토요일") && listBox2.Text.Equals("맑음"))
                a[0] = 22;
            else if (listBox1.Text.Equals("토요일") && listBox2.Text.Equals("비"))
                a[0] = 23;
            else if (listBox1.Text.Equals("토요일") && listBox2.Text.Equals("구름"))
                a[0] = 24;
            else if (listBox1.Text.Equals("토요일") && listBox2.Text.Equals("눈"))
                a[0] = 25;
            else if (listBox1.Text.Equals("일요일") && listBox2.Text.Equals("맑음"))
                a[0] = 26;
            else if (listBox1.Text.Equals("일요일") && listBox2.Text.Equals("비"))
                a[0] = 27;
            else if (listBox1.Text.Equals("일요일") && listBox2.Text.Equals("구름"))
                a[0] = 28;
            else if (listBox1.Text.Equals("일요일") && listBox2.Text.Equals("눈"))
                a[0] = 29;
            else
                a[0] = 0;
            return a;
        }
        private String SelectedDayWeather()
        {
            String a = String.Empty;
            if (day.Equals("월") && weather.Equals("맑음"))
                a = "1";
            else if (day.Equals("월") && weather.Equals("비"))
                a = "2";
            else if (day.Equals("월") && weather.Equals("구름"))
                a = "3";
            else if (day.Equals("월") && weather.Equals("눈"))
                a = "4";
            else if (day.Equals("화") && weather.Equals("맑음"))
                a = "5";
            else if (day.Equals("화") && weather.Equals("비"))
                a = "6";
            else if (day.Equals("화") && weather.Equals("구름"))
                a = "7";
            else if (day.Equals("화") && weather.Equals("눈"))
                a = "8";
            else if (day.Equals("수") && weather.Equals("맑음"))
                a = "10";
            else if (day.Equals("수") && weather.Equals("비"))
                a = "11";
            else if (day.Equals("수") && weather.Equals("구름"))
                a = "12";
            else if (day.Equals("수") && weather.Equals("눈"))
                a = "13";
            else if (day.Equals("목") && weather.Equals("맑음"))
                a = "14";
            else if (day.Equals("목") && weather.Equals("비"))
                a = "15";
            else if (day.Equals("목") && weather.Equals("구름"))
                a = "16";
            else if (day.Equals("목") && weather.Equals("눈"))
                a = "17";
            else if (day.Equals("금") && weather.Equals("맑음"))
                a = "18";
            else if (day.Equals("금") && weather.Equals("비"))
                a = "19";
            else if (day.Equals("금") && weather.Equals("구름"))
                a = "20";
            else if (day.Equals("금") && weather.Equals("눈"))
                a = "21";
            else if (day.Equals("토") && weather.Equals("맑음"))
                a = "22";
            else if (day.Equals("토") && weather.Equals("비"))
                a = "23";
            else if (day.Equals("토") && weather.Equals("구름"))
                a = "24";
            else if (day.Equals("토") && weather.Equals("눈"))
                a = "25";
            else if (day.Equals("일") && weather.Equals("맑음"))
                a = "26";
            else if (day.Equals("일") && weather.Equals("비"))
                a = "27";
            else if (day.Equals("일") && weather.Equals("구름"))
                a = "28";
            else if (day.Equals("일") && weather.Equals("눈"))
                a = "29";
            else
                a = "0";
            return a;
        }

        private void changePasswordBtn_Click(object sender, EventArgs e)
        {
            if (!serialPassword.IsOpen)
            {
                MessageBox.Show("포트를 연결하세요");
                return;
            }
            string path = @"c:\PASSWORD\password.txt";
            string originPassword = "";
            using (StreamReader sr = File.OpenText(path))
            {
                string s = "";

                while ((s = sr.ReadLine()) != null)
                {
                    originPassword += s;
                }
            }
            string curPass = currentPassword.Text.ToString().Trim();
            string newPass = newPassword.Text.ToString().Trim();
            string cfmPass = confirmPassword.Text.ToString().Trim();

            if (curPass.Length == 0 || newPass.Length == 0 || cfmPass.Length == 0)
            {
                MessageBox.Show("암호를 입력해 주세요");
            }
            else if (!curPass.Equals(originPassword))
            {
                MessageBox.Show("현재암호와 DB에 저장된 암호가 다릅니다.");
            }
            else if (!newPass.Equals(cfmPass))
            {
                MessageBox.Show("새로운 암호와 암호 확인이 다릅니다.");
            }
            else
            {
                using (StreamWriter sw = new StreamWriter(path))
                {
                    byte[] sendData = new byte[1];
                    sendData[0] = Convert.ToByte('d');
                    serialPassword.Write(sendData, 0, sendData.Length);
                    Thread.Sleep(100);
                    foreach (Char c in cfmPass.ToCharArray())
                    {
                        Thread.Sleep(500);
                        sendData[0] = Convert.ToByte(c);
                        serialPassword.Write(sendData, 0, sendData.Length);
                        sw.Write(c.ToString());
                    }
                }
                MessageBox.Show("암호가 변경되었습니다.");
                currentPassword.Text = "";
                newPassword.Text = "";
                confirmPassword.Text = "";
            }
        }
        private void initPasswordBtn_Click(object sender, EventArgs e)
        {
            if (!serialPassword.IsOpen)
            {
                MessageBox.Show("포트를 연결하세요");
                return;
            }
            if (DialogResult.OK == MessageBox.Show("확인을 누르시면 암호가 초기화 됩니다.\n한번 초기화 되면 복구하실 수 없습니다.\n초기화 하시겠습니까?", "알림", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation))
            {
                string path = @"c:\PASSWORD\password.txt";
                if (!File.Exists(path))
                {
                    using (StreamWriter sw = File.CreateText(path))
                    {
                        byte[] sendData = new byte[1];
                        sendData[0] = Convert.ToByte('d');
                        serialPassword.Write(sendData, 0, sendData.Length);
                        Thread.Sleep(100);
                        for (int i = 0; i < 8; i++)
                        {
                            Thread.Sleep(500);
                            sendData[0] = Convert.ToByte('1');
                            serialPassword.Write(sendData, 0, sendData.Length);
                            sw.Write(1);
                        }
                    }
                }
                else
                {
                    using (StreamWriter sw = new StreamWriter(path))
                    {
                        byte[] sendData = new byte[1];
                        sendData[0] = Convert.ToByte('d');
                        serialPassword.Write(sendData, 0, sendData.Length);
                        Thread.Sleep(100);
                        for (int i = 0; i < 8; i++)
                        {
                            Thread.Sleep(500);
                            sendData[0] = Convert.ToByte('1');
                            serialPassword.Write(sendData, 0, sendData.Length);
                            sw.Write(1);
                        }
                    }
                }
                MessageBox.Show("암호가 초기화 되었습니다.");
            }
            else
            {
                MessageBox.Show("암호 초기화를 취소 하였습니다.");
            }

        }
        private void currentPassword_TextChanged(object sender, EventArgs e)
        {
            checkPasswordTextBox(sender as TextBox);
        }
        private void newPassword_TextChanged(object sender, EventArgs e)
        {
            checkPasswordTextBox(sender as TextBox);
        }
        private void confirmPassword_TextChanged(object sender, EventArgs e)
        {
            checkPasswordTextBox(sender as TextBox);
        }
        private void checkPasswordTextBox(TextBox source)
        {
            if (source.Text.Length > 8)
            {
                MessageBox.Show("최대 8글자입니다.\n 8글자에 맞춰 주시기 바랍니다");
                return;
            }
            else
            {
                int selectionStart = source.SelectionStart;
                int selectionLength = source.SelectionLength;
                String newText = String.Empty;
                foreach (Char c in source.Text.ToCharArray())
                {
                    if (Char.IsDigit(c))
                    {
                        newText += c;
                    }
                }
                source.Text = newText;
                source.SelectionStart = selectionStart <= source.Text.Length ? selectionStart : source.Text.Length;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            indicatorStr6.Text = "    --";
            indicatorStr7.Text = "    --";
            indicatorStr8.Text = "    --";
            indicatorStr9.Text = "    --";
            indicatorStr10.Text = "    --";
            indicatorStr11.Text = "    --";
            indicatorStr12.Text = "    --";
            indicatorStr13.Text = "    --";
        }

        public SerialPort getSerialNews()
        {
            return this.serialNews;
        }
        public SerialPort getSerialCook()
        {
            return this.serialCook;
        }
        public SerialPort getSerialWeather()
        {
            return this.serialWeather;
        }
        public SerialPort getSerialPassword()
        {
            return this.serialPassword;
        }
        public RichTextBox getReceiveSocketTextBox()
        {
            return this.recive_socketTextBox;
        }
        public Label getIndicatorSocket()
        {
            return this.Indicator_socket;
        }
        /********************소켓부분*****************************/
        public string getIP()
        {
            Regex regex = new Regex(@"^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$");
            foreach (IPAddress ip in Dns.GetHostEntry(Dns.GetHostName()).AddressList)
            {
                if (regex.IsMatch(ip.ToString()))
                {
                    return ip.ToString();
                }
            }
            return null;
        }
        public void sockmain()
        {
            //MessageBox.Show(Dns.GetHostEntry(Dns.GetHostName()).AddressList[1].ToString());
            //MessageBox.Show(getIP());
            IPAddress serverIP = IPAddress.Parse(socketip.Text);//ip주소 초기화
            IPEndPoint serverEndPoint = new IPEndPoint(serverIP, Int32.Parse(socketport.Text));//ip point 초기화

            try
            {
                //서버 소켓 생성
                Server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                Server.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReuseAddress, true);

                Server.Bind(serverEndPoint);
                Server.Listen(10);
   
                while (true)
                {
                    //클라이언트의 접속 시도가 있으면 accept
                    AcceptClient = Server.Accept();
                    LEDClient client = new LEDClient(this, AcceptClient);
                    client.Start();
                }
            }
            catch (System.Net.Sockets.SocketException socketEx)
            {
                recive_socketTextBox.Text = socketEx.Message;
            }
            catch (System.Exception commonEx)
            {
                recive_socketTextBox.Text = commonEx.Message;
            }
            finally
            {
                Server.Close();
            }
        }
 
        public static int byteArrayDefrag(byte[] sData)
        {
            int endLength = 0;

            for (int i = 0; i < sData.Length; i++)
            {
                if ((byte)sData[i] != (byte)0)
                {
                    endLength = i;
                }
            }

            return endLength;
        }

        private void socket_connect_Click(object sender, EventArgs e)
        {
            socket_thread = new Thread(new ThreadStart(sockmain));
            socket_thread.Start();
            Indicator_socket.Text = "접속 대기";
        }

        private void socket_discon_Click(object sender, EventArgs e)
        {
            Server.Close();
            Indicator_socket.Text = "접속 끊김";
            recive_socketTextBox.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.ExitThread();
            Environment.Exit(0);
        }

        //소켓 클라이언트들이 접속할때마다 이 클래스의 객체가 하나씩 만들어지고 쓰레드가 돌아간다.
        class LEDClient
        {
            SerialPort serialNews;
            SerialPort serialCook;
            SerialPort serialPassword;
            RichTextBox recive_socketTextBox;
            Label indicatorSocket;
            Socket inClient;
            Thread threadClient;

            static int clientCount = 0;

            byte[] getByte = new byte[1024];//받은 데이터
            byte[] setByte = new byte[1024];//보낼 데이터

            public LEDClient(LEDControlSystemMainForm thisForm, Socket inClient)
            {
                this.serialNews = thisForm.getSerialNews();
                this.serialCook = thisForm.getSerialCook();
                this.serialPassword = thisForm.getSerialPassword();
                this.recive_socketTextBox = thisForm.getReceiveSocketTextBox();
                this.indicatorSocket = thisForm.getIndicatorSocket();
                this.inClient = inClient;
                LEDClient.clientCount++;
            }

            public void Start()
            {
                threadClient =  new Thread(new ThreadStart(Run));
                threadClient.Start();
            }

            public void Run()
            {
                string stringbyte = null;
                bool check = false;
                indicatorSocket.Text = "C"+LEDClient.clientCount+" 접속";
                recive_socketTextBox.Text += "C" + LEDClient.clientCount + " 접속\n";
                do
                {
                    check = false;
                    //클라이언트에서 데이터 받는다.
                    inClient.Receive(getByte, 0, getByte.Length, SocketFlags.None);
                    stringbyte = Encoding.ASCII.GetString(getByte);

                    if (stringbyte != String.Empty)
                    {
                        int getValueLength = 0;
                        getValueLength = byteArrayDefrag(getByte);
                        stringbyte = Encoding.UTF8.GetString(getByte, 0, getValueLength + 1);
                        String[] resultData;
                        resultData = stringbyte.Split(';');

                        if (resultData[0] == "lamp" && resultData[1] == "1")
                        {
                            Lamp1(resultData[2], resultData[3]);
                            RichTextBoxScrollDown();
                        }
                        else if (resultData[0] == "lamp" && resultData[1] == "2")
                        {
                            Lamp2(resultData[2], resultData[3]);
                            RichTextBoxScrollDown();
                        }
                        else if (resultData[0] == "door" && resultData[1] == "close")
                        {
                            //MessageBox.Show("door close");
                            DoorClose();
                            RichTextBoxScrollDown();
                        }
                        else if (resultData[0] == "door" && resultData[1] == "open")
                        {
                            //MessageBox.Show("door open");
                            DoorOpen(resultData[2]);
                            RichTextBoxScrollDown();
                        }
                        else if (resultData[0] == "doorpass")
                        {
                            DoorChange(resultData[1], resultData[2], resultData[3]);
                            RichTextBoxScrollDown();
                        }
                        else if (resultData[0] == "gas")
                        {
                            GasOff();
                            RichTextBoxScrollDown();
                        }
                        
                        int dlen = resultData.Length;
                        for (int i = 0; i < dlen - 1; i++)
                        {
                            check = true;
                           // recive_socketTextBox.Text += resultData[i] + " | ";
                        }

                        if (check)
                        {
                            recive_socketTextBox.Text += "C" + LEDClient.clientCount + " - " + stringbyte + "\n";
                            RichTextBoxScrollDown();
                        }
                    }
                    
                    getByte = new byte[1024];
                    setByte = new byte[1024];
                } while (check);
                indicatorSocket.Text = "C" + LEDClient.clientCount + " 접속 끊김";
                recive_socketTextBox.Text += "C" + LEDClient.clientCount + " 접속 끊김\n";
            }

            private void Lamp1(String bri, String onoff)
            {
                recive_socketTextBox.Text += "C" + LEDClient.clientCount + " - lamp1 " + bri + onoff + "\n";
                if (!serialNews.IsOpen)
                {
                    recive_socketTextBox.Text += "뉴스 - 포트를 연결하세요\n";
                    return;
                }
                if (bri == "off")
                {
                    serialNews.Write("e");
                }
                else if (bri != "off" && onoff == "on")
                {
                    if (bri == "1")
                        serialNews.Write("a");
                    else if (bri == "2")
                        serialNews.Write("b");
                    else if (bri == "3")
                        serialNews.Write("c");
                    else if (bri == "4")
                        serialNews.Write("d");
                }
            }
            private void Lamp2(String bri, String onoff)
            {
                if (!serialCook.IsOpen)
                {
                    recive_socketTextBox.Text += "레시피 - 포트를 연결하세요\n";
                    return;
                }
                recive_socketTextBox.Text += "C" + LEDClient.clientCount + " - lamp2 " + bri + onoff + "\n";
                if (bri == "off")
                {
                    serialCook.Write("e");
                }
                if (bri != "off" && onoff == "on")
                {
                    if (bri == "1")
                        serialCook.Write("a");
                    else if (bri == "2")
                        serialCook.Write("b");
                    else if (bri == "3")
                        serialCook.Write("c");
                    else if (bri == "4")
                        serialCook.Write("d");
                }
            }
            private void DoorClose()
            {
                if (!serialPassword.IsOpen)
                {
                    recive_socketTextBox.Text += "도어락 - 포트를 연결하세요\n";
                    return;
                }
                recive_socketTextBox.Text += "C" + LEDClient.clientCount + " - DoorClose" + "\n";
                serialPassword.Write("b");
            }
            private void DoorOpen(String str)
            {
                recive_socketTextBox.Text += "C" + LEDClient.clientCount + " - DoorOpen" + "\n";
               /* if (!serialPassword.IsOpen)
                {
                    recive_socketTextBox.Text += "도어락 - 포트를 연결하세요\n";
                    return;
                }*/
                string path = @"c:\PASSWORD\password.txt";
                string originPassword = String.Empty;
                using (StreamReader sr = File.OpenText(path))
                {
                    string s = "";

                    while ((s = sr.ReadLine()) != null)
                    {
                        originPassword += s;
                    }
                }
                //MessageBox.Show(originPassword+", "+str);
                if (originPassword.Equals(str))
                {
                    //MessageBox.Show("test code1");
                    serialPassword.Write("a");
                }
                else
                {
                    recive_socketTextBox.Text += "C" + LEDClient.clientCount + " - 메세지가 맞지 않습니다." + "\n";
                    string sendstring = "패스워드가 맞지 않습니다";
                    if (sendstring != String.Empty)
                    {
                        setByte = Encoding.UTF8.GetBytes(sendstring);
                        inClient.Send(setByte, 0, setByte.Length, SocketFlags.None);
                    }
                    setByte = new byte[1024];
                }
            }
            private void DoorChange(String curpass, String newpasss, String confpass)
            {
                recive_socketTextBox.Text += "C" + LEDClient.clientCount + " - DoorPasswordChange\n";

                if (!serialPassword.IsOpen)
                {
                    recive_socketTextBox.Text += "도어락 - 포트를 연결하세요\n";
                    return;
                }
                string path = @"c:\PASSWORD\password.txt";
                string originPassword = "";
                using (StreamReader sr = File.OpenText(path))
                {
                    string s = "";

                    while ((s = sr.ReadLine()) != null)
                    {
                        originPassword += s;
                    }
                }
                string curPass = curpass;
                string newPass = newpasss;
                string cfmPass = confpass;

                if (curPass.Length == 0 || newPass.Length == 0 || cfmPass.Length == 0)
                {
                    recive_socketTextBox.Text += "C" + LEDClient.clientCount + " - 암호를 입력하세요\n";
                }
                else if (!curPass.Equals(originPassword))
                {
                    recive_socketTextBox.Text += "C" + LEDClient.clientCount + " - 현재 암호와 DB의 암호가 다릅니다\n";
                }
                else if (!newPass.Equals(cfmPass))
                {
                    recive_socketTextBox.Text += "C" + LEDClient.clientCount + " - 새로운 암호와 확인이 다릅니다\n";
                }
                else
                {
                    using (StreamWriter sw = new StreamWriter(path))
                    {
                        byte[] sendData = new byte[1];
                        sendData[0] = Convert.ToByte('d');
                        serialPassword.Write(sendData, 0, sendData.Length);
                        Thread.Sleep(100);
                        foreach (Char c in cfmPass.ToCharArray())
                        {
                            Thread.Sleep(500);
                            sendData[0] = Convert.ToByte(c);
                            serialPassword.Write(sendData, 0, sendData.Length);
                            sw.Write(c.ToString());
                        }
                    }
                    recive_socketTextBox.Text += "C" + LEDClient.clientCount + " - 암호가 변경되었습니다\n";
                }
            }
            private void GasOff()
            {
                if (!serialPassword.IsOpen)
                {
                    recive_socketTextBox.Text += "도어락 - 포트를 연결하세요\n";
                    return;
                }
                recive_socketTextBox.Text += "C" + LEDClient.clientCount + " - GassOff\n";
                serialPassword.Write("c");
            }
            private void RichTextBoxScrollDown()
            {
                int line = recive_socketTextBox.Text.Split('\n').Length-1; //엔터(\n)기호로 split한 갯수-1 이 총 줄 라인 수이다.
                int idx = recive_socketTextBox.GetFirstCharIndexFromLine(line);
                recive_socketTextBox.Select(idx, 0);
                recive_socketTextBox.ScrollToCaret();
            }
        }
    }
}