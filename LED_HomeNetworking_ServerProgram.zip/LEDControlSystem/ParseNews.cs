﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Net;
using System.IO;
using HtmlAgilityPack;

namespace LEDControlSystem
{

    class ParseNews : Data
    {
        private DataList list;
        private WebRequest request;
        private HttpWebResponse response;
        private Stream dataStream;
        private HtmlAgilityPack.HtmlDocument doc;
        private string url;

        public ParseNews()
        {
            url = "http://media.daum.net/?t__nil_bestservice=news";
            request = WebRequest.Create(url);
            request.Credentials = CredentialCache.DefaultCredentials;
            response = (HttpWebResponse)request.GetResponse();
            dataStream = response.GetResponseStream();
            doc = new HtmlAgilityPack.HtmlDocument();
            doc.Load(dataStream, Encoding.UTF8);
            list = new DataList();
        }

        public DataList getDataList()
        {
            return list;
        }

        public void parse(){
            list.Clear();
            HtmlNodeCollection nodeList = doc.DocumentNode.SelectNodes("//ul[@class='Section_list CT_ZONE_SecList']");
            foreach (HtmlNode node in nodeList)
            {
                HtmlNodeCollection subNodeList = node.SelectNodes(".//li");
                foreach (HtmlNode subNode in subNodeList)
                {
                    Data data = new Data();
                    HtmlNodeCollection titleNodeList = subNode.SelectNodes(".//a");
                    HtmlNode titleNode = titleNodeList[0];

                    data.Title = titleNode.InnerText.ToString().Replace("&quot;","");
                    data.Title = data.Title.Replace("&#39;", "");
                    data.Exp = "";//본문이 필요할시 여기에서 추가
                    list.Add(data);
                }
            }
        }
    }
}
