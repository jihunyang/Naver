﻿namespace LEDControlSystem
{
    partial class LEDControlSystemMainForm
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.newsTextBox = new System.Windows.Forms.RichTextBox();
            this.connectTest = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cookTextBox = new System.Windows.Forms.RichTextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.weatherTextBox = new System.Windows.Forms.RichTextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.indicatorStrDW = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.submitWeatherButton = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.testReadTextBox = new System.Windows.Forms.RichTextBox();
            this.testWriteTextBox = new System.Windows.Forms.RichTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.connectNewsButton = new System.Windows.Forms.Button();
            this.disconnectNewsButton = new System.Windows.Forms.Button();
            this.disconnectCookButton = new System.Windows.Forms.Button();
            this.connectCookButton = new System.Windows.Forms.Button();
            this.disconnectWeatherButton = new System.Windows.Forms.Button();
            this.connectWeatherButton = new System.Windows.Forms.Button();
            this.disconnectTest = new System.Windows.Forms.Button();
            this.submitTest = new System.Windows.Forms.Button();
            this.portComboBox1 = new System.Windows.Forms.ComboBox();
            this.portComboBox2 = new System.Windows.Forms.ComboBox();
            this.portComboBox3 = new System.Windows.Forms.ComboBox();
            this.portComboBox5 = new System.Windows.Forms.ComboBox();
            this.serialTest = new System.IO.Ports.SerialPort(this.components);
            this.serialNews = new System.IO.Ports.SerialPort(this.components);
            this.serialCook = new System.IO.Ports.SerialPort(this.components);
            this.serialWeather = new System.IO.Ports.SerialPort(this.components);
            this.refreshNewsButton = new System.Windows.Forms.Button();
            this.refreshCookButton = new System.Windows.Forms.Button();
            this.serialPassword = new System.IO.Ports.SerialPort(this.components);
            this.portComboBox4 = new System.Windows.Forms.ComboBox();
            this.passDisconnectBtn = new System.Windows.Forms.Button();
            this.passConnectBtn = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.initPasswordBtn = new System.Windows.Forms.Button();
            this.changePasswordBtn = new System.Windows.Forms.Button();
            this.confirmPassword = new System.Windows.Forms.TextBox();
            this.newPassword = new System.Windows.Forms.TextBox();
            this.currentPassword = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.indicatorStr1 = new System.Windows.Forms.Label();
            this.indicatorStr2 = new System.Windows.Forms.Label();
            this.indicatorStr3 = new System.Windows.Forms.Label();
            this.indicatorStr4 = new System.Windows.Forms.Label();
            this.indicatorStr5 = new System.Windows.Forms.Label();
            this.indicatorStr6 = new System.Windows.Forms.Label();
            this.indicatorStr7 = new System.Windows.Forms.Label();
            this.indicatorStr8 = new System.Windows.Forms.Label();
            this.indicatorStr9 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.indicatorStr13 = new System.Windows.Forms.Label();
            this.indicatorStr12 = new System.Windows.Forms.Label();
            this.indicatorStr11 = new System.Windows.Forms.Label();
            this.indicatorStr10 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.Indicator_socket = new System.Windows.Forms.Label();
            this.socketport = new System.Windows.Forms.TextBox();
            this.socketip = new System.Windows.Forms.TextBox();
            this.socketportLabel = new System.Windows.Forms.Label();
            this.socketipLabel = new System.Windows.Forms.Label();
            this.socket_discon = new System.Windows.Forms.Button();
            this.socket_connect = new System.Windows.Forms.Button();
            this.recive_socketTextBox = new System.Windows.Forms.RichTextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.formCloseBtn = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.newsTextBox);
            this.groupBox1.Location = new System.Drawing.Point(14, 55);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(458, 127);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Today Top news";
            // 
            // newsTextBox
            // 
            this.newsTextBox.Location = new System.Drawing.Point(8, 20);
            this.newsTextBox.Name = "newsTextBox";
            this.newsTextBox.Size = new System.Drawing.Size(445, 101);
            this.newsTextBox.TabIndex = 0;
            this.newsTextBox.Text = "";
            // 
            // connectTest
            // 
            this.connectTest.Location = new System.Drawing.Point(510, 62);
            this.connectTest.Name = "connectTest";
            this.connectTest.Size = new System.Drawing.Size(75, 25);
            this.connectTest.TabIndex = 21;
            this.connectTest.Text = "connect";
            this.connectTest.UseVisualStyleBackColor = true;
            this.connectTest.Click += new System.EventHandler(this.connectTest_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cookTextBox);
            this.groupBox2.Location = new System.Drawing.Point(14, 236);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(458, 129);
            this.groupBox2.TabIndex = 3;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Cook Recipe";
            // 
            // cookTextBox
            // 
            this.cookTextBox.Location = new System.Drawing.Point(7, 20);
            this.cookTextBox.Name = "cookTextBox";
            this.cookTextBox.Size = new System.Drawing.Size(445, 98);
            this.cookTextBox.TabIndex = 1;
            this.cookTextBox.Text = "";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.groupBox9);
            this.groupBox3.Controls.Add(this.groupBox8);
            this.groupBox3.Location = new System.Drawing.Point(14, 419);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(458, 153);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Day, Weather";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.weatherTextBox);
            this.groupBox9.Controls.Add(this.label34);
            this.groupBox9.Location = new System.Drawing.Point(291, 19);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(161, 126);
            this.groupBox9.TabIndex = 5;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "자동 전송";
            // 
            // weatherTextBox
            // 
            this.weatherTextBox.Location = new System.Drawing.Point(14, 65);
            this.weatherTextBox.Name = "weatherTextBox";
            this.weatherTextBox.Size = new System.Drawing.Size(132, 36);
            this.weatherTextBox.TabIndex = 1;
            this.weatherTextBox.Text = "";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(22, 40);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(109, 12);
            this.label34.TabIndex = 2;
            this.label34.Text = "전송될 요일과 날씨";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.listBox2);
            this.groupBox8.Controls.Add(this.listBox1);
            this.groupBox8.Controls.Add(this.indicatorStrDW);
            this.groupBox8.Controls.Add(this.label1);
            this.groupBox8.Controls.Add(this.label33);
            this.groupBox8.Controls.Add(this.submitWeatherButton);
            this.groupBox8.Location = new System.Drawing.Point(7, 19);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(278, 126);
            this.groupBox8.TabIndex = 4;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "수동 전송";
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.ItemHeight = 12;
            this.listBox2.Items.AddRange(new object[] {
            "맑음",
            "비",
            "구름",
            "눈"});
            this.listBox2.Location = new System.Drawing.Point(197, 17);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(75, 52);
            this.listBox2.TabIndex = 1;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 12;
            this.listBox1.Items.AddRange(new object[] {
            "월요일",
            "화요일",
            "수요일",
            "목요일",
            "금요일",
            "토요일",
            "일요일"});
            this.listBox1.Location = new System.Drawing.Point(61, 21);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(75, 88);
            this.listBox1.TabIndex = 0;
            // 
            // indicatorStrDW
            // 
            this.indicatorStrDW.AutoSize = true;
            this.indicatorStrDW.Location = new System.Drawing.Point(142, 74);
            this.indicatorStrDW.Name = "indicatorStrDW";
            this.indicatorStrDW.Size = new System.Drawing.Size(0, 12);
            this.indicatorStrDW.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 2;
            this.label1.Text = "요일선택";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(142, 37);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(53, 12);
            this.label33.TabIndex = 2;
            this.label33.Text = "날씨선택";
            // 
            // submitWeatherButton
            // 
            this.submitWeatherButton.Location = new System.Drawing.Point(169, 92);
            this.submitWeatherButton.Name = "submitWeatherButton";
            this.submitWeatherButton.Size = new System.Drawing.Size(75, 25);
            this.submitWeatherButton.TabIndex = 28;
            this.submitWeatherButton.Text = "submit";
            this.submitWeatherButton.UseVisualStyleBackColor = true;
            this.submitWeatherButton.Click += new System.EventHandler(this.submitWeatherButton_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.testReadTextBox);
            this.groupBox4.Controls.Add(this.testWriteTextBox);
            this.groupBox4.Location = new System.Drawing.Point(488, 98);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(275, 93);
            this.groupBox4.TabIndex = 5;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Test Communication";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(20, 57);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(30, 12);
            this.label7.TabIndex = 3;
            this.label7.Text = "read";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(32, 12);
            this.label6.TabIndex = 2;
            this.label6.Text = "write";
            // 
            // testReadTextBox
            // 
            this.testReadTextBox.Location = new System.Drawing.Point(56, 54);
            this.testReadTextBox.Name = "testReadTextBox";
            this.testReadTextBox.Size = new System.Drawing.Size(189, 30);
            this.testReadTextBox.TabIndex = 1;
            this.testReadTextBox.Text = "";
            // 
            // testWriteTextBox
            // 
            this.testWriteTextBox.Location = new System.Drawing.Point(56, 20);
            this.testWriteTextBox.Name = "testWriteTextBox";
            this.testWriteTextBox.Size = new System.Drawing.Size(189, 28);
            this.testWriteTextBox.TabIndex = 0;
            this.testWriteTextBox.Text = "";
            this.testWriteTextBox.MouseDown += new System.Windows.Forms.MouseEventHandler(this.testWriteTextBox_MouseDown);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 12);
            this.label2.TabIndex = 6;
            this.label2.Text = "port : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 211);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 12);
            this.label3.TabIndex = 8;
            this.label3.Text = "port : ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 394);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 12);
            this.label4.TabIndex = 9;
            this.label4.Text = "port : ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(494, 35);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 12);
            this.label5.TabIndex = 10;
            this.label5.Text = "port : ";
            // 
            // connectNewsButton
            // 
            this.connectNewsButton.Location = new System.Drawing.Point(213, 24);
            this.connectNewsButton.Name = "connectNewsButton";
            this.connectNewsButton.Size = new System.Drawing.Size(75, 25);
            this.connectNewsButton.TabIndex = 15;
            this.connectNewsButton.Text = "connect";
            this.connectNewsButton.UseVisualStyleBackColor = true;
            this.connectNewsButton.Click += new System.EventHandler(this.connectNewsButton_Click);
            // 
            // disconnectNewsButton
            // 
            this.disconnectNewsButton.Location = new System.Drawing.Point(295, 24);
            this.disconnectNewsButton.Name = "disconnectNewsButton";
            this.disconnectNewsButton.Size = new System.Drawing.Size(75, 25);
            this.disconnectNewsButton.TabIndex = 16;
            this.disconnectNewsButton.Text = "disconnect";
            this.disconnectNewsButton.UseVisualStyleBackColor = true;
            this.disconnectNewsButton.Click += new System.EventHandler(this.disconnectNewsButton_Click);
            // 
            // disconnectCookButton
            // 
            this.disconnectCookButton.Location = new System.Drawing.Point(295, 205);
            this.disconnectCookButton.Name = "disconnectCookButton";
            this.disconnectCookButton.Size = new System.Drawing.Size(75, 25);
            this.disconnectCookButton.TabIndex = 18;
            this.disconnectCookButton.Text = "disconnect";
            this.disconnectCookButton.UseVisualStyleBackColor = true;
            this.disconnectCookButton.Click += new System.EventHandler(this.disconnectCookButton_Click);
            // 
            // connectCookButton
            // 
            this.connectCookButton.Location = new System.Drawing.Point(214, 205);
            this.connectCookButton.Name = "connectCookButton";
            this.connectCookButton.Size = new System.Drawing.Size(75, 25);
            this.connectCookButton.TabIndex = 17;
            this.connectCookButton.Text = "connect";
            this.connectCookButton.UseVisualStyleBackColor = true;
            this.connectCookButton.Click += new System.EventHandler(this.connectCookButton_Click);
            // 
            // disconnectWeatherButton
            // 
            this.disconnectWeatherButton.Location = new System.Drawing.Point(294, 388);
            this.disconnectWeatherButton.Name = "disconnectWeatherButton";
            this.disconnectWeatherButton.Size = new System.Drawing.Size(75, 25);
            this.disconnectWeatherButton.TabIndex = 20;
            this.disconnectWeatherButton.Text = "disconnect";
            this.disconnectWeatherButton.UseVisualStyleBackColor = true;
            this.disconnectWeatherButton.Click += new System.EventHandler(this.disconnectWeatherButton_Click);
            // 
            // connectWeatherButton
            // 
            this.connectWeatherButton.Location = new System.Drawing.Point(213, 388);
            this.connectWeatherButton.Name = "connectWeatherButton";
            this.connectWeatherButton.Size = new System.Drawing.Size(75, 25);
            this.connectWeatherButton.TabIndex = 19;
            this.connectWeatherButton.Text = "connect";
            this.connectWeatherButton.UseVisualStyleBackColor = true;
            this.connectWeatherButton.Click += new System.EventHandler(this.connectWeatherButton_Click);
            // 
            // disconnectTest
            // 
            this.disconnectTest.Location = new System.Drawing.Point(591, 62);
            this.disconnectTest.Name = "disconnectTest";
            this.disconnectTest.Size = new System.Drawing.Size(75, 25);
            this.disconnectTest.TabIndex = 22;
            this.disconnectTest.Text = "disconnect";
            this.disconnectTest.UseVisualStyleBackColor = true;
            this.disconnectTest.Click += new System.EventHandler(this.disconnectTest_Click);
            // 
            // submitTest
            // 
            this.submitTest.Location = new System.Drawing.Point(672, 62);
            this.submitTest.Name = "submitTest";
            this.submitTest.Size = new System.Drawing.Size(75, 25);
            this.submitTest.TabIndex = 23;
            this.submitTest.Text = "submit";
            this.submitTest.UseVisualStyleBackColor = true;
            this.submitTest.Click += new System.EventHandler(this.submitTest_Click);
            // 
            // portComboBox1
            // 
            this.portComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.portComboBox1.FormattingEnabled = true;
            this.portComboBox1.Location = new System.Drawing.Point(67, 29);
            this.portComboBox1.Name = "portComboBox1";
            this.portComboBox1.Size = new System.Drawing.Size(121, 20);
            this.portComboBox1.TabIndex = 24;
            // 
            // portComboBox2
            // 
            this.portComboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.portComboBox2.FormattingEnabled = true;
            this.portComboBox2.Location = new System.Drawing.Point(68, 208);
            this.portComboBox2.Name = "portComboBox2";
            this.portComboBox2.Size = new System.Drawing.Size(121, 20);
            this.portComboBox2.TabIndex = 25;
            // 
            // portComboBox3
            // 
            this.portComboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.portComboBox3.FormattingEnabled = true;
            this.portComboBox3.Location = new System.Drawing.Point(78, 391);
            this.portComboBox3.Name = "portComboBox3";
            this.portComboBox3.Size = new System.Drawing.Size(121, 20);
            this.portComboBox3.TabIndex = 26;
            // 
            // portComboBox5
            // 
            this.portComboBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.portComboBox5.FormattingEnabled = true;
            this.portComboBox5.Location = new System.Drawing.Point(531, 31);
            this.portComboBox5.Name = "portComboBox5";
            this.portComboBox5.Size = new System.Drawing.Size(121, 20);
            this.portComboBox5.TabIndex = 27;
            // 
            // serialTest
            // 
            this.serialTest.BaudRate = 57600;
            this.serialTest.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialTest_DataReceived);
            // 
            // serialNews
            // 
            this.serialNews.PortName = "COM5";
            this.serialNews.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialNews_DataReceived);
            // 
            // serialCook
            // 
            this.serialCook.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialCook_DataReceived);
            // 
            // serialWeather
            // 
            this.serialWeather.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialWeather_DataReceived);
            // 
            // refreshNewsButton
            // 
            this.refreshNewsButton.Location = new System.Drawing.Point(376, 24);
            this.refreshNewsButton.Name = "refreshNewsButton";
            this.refreshNewsButton.Size = new System.Drawing.Size(75, 25);
            this.refreshNewsButton.TabIndex = 29;
            this.refreshNewsButton.Text = "Refresh";
            this.refreshNewsButton.UseVisualStyleBackColor = true;
            this.refreshNewsButton.Click += new System.EventHandler(this.refreshNewsButton_Click);
            // 
            // refreshCookButton
            // 
            this.refreshCookButton.Location = new System.Drawing.Point(376, 205);
            this.refreshCookButton.Name = "refreshCookButton";
            this.refreshCookButton.Size = new System.Drawing.Size(75, 25);
            this.refreshCookButton.TabIndex = 30;
            this.refreshCookButton.Text = "refresh";
            this.refreshCookButton.UseVisualStyleBackColor = true;
            this.refreshCookButton.Click += new System.EventHandler(this.refreshCookButton_Click);
            // 
            // serialPassword
            // 
            this.serialPassword.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPassword_DataReceived);
            // 
            // portComboBox4
            // 
            this.portComboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.portComboBox4.FormattingEnabled = true;
            this.portComboBox4.Location = new System.Drawing.Point(78, 602);
            this.portComboBox4.Name = "portComboBox4";
            this.portComboBox4.Size = new System.Drawing.Size(121, 20);
            this.portComboBox4.TabIndex = 34;
            // 
            // passDisconnectBtn
            // 
            this.passDisconnectBtn.Location = new System.Drawing.Point(294, 601);
            this.passDisconnectBtn.Name = "passDisconnectBtn";
            this.passDisconnectBtn.Size = new System.Drawing.Size(75, 25);
            this.passDisconnectBtn.TabIndex = 33;
            this.passDisconnectBtn.Text = "disconnect";
            this.passDisconnectBtn.UseVisualStyleBackColor = true;
            this.passDisconnectBtn.Click += new System.EventHandler(this.passDisconnectBtn_Click);
            // 
            // passConnectBtn
            // 
            this.passConnectBtn.Location = new System.Drawing.Point(213, 601);
            this.passConnectBtn.Name = "passConnectBtn";
            this.passConnectBtn.Size = new System.Drawing.Size(75, 25);
            this.passConnectBtn.TabIndex = 32;
            this.passConnectBtn.Text = "connect";
            this.passConnectBtn.UseVisualStyleBackColor = true;
            this.passConnectBtn.Click += new System.EventHandler(this.passConnectBtn_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(34, 607);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(38, 12);
            this.label8.TabIndex = 31;
            this.label8.Text = "port : ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(14, 10);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 12);
            this.label9.TabIndex = 35;
            this.label9.Text = "서재 - 뉴스보기";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 189);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(103, 12);
            this.label10.TabIndex = 36;
            this.label10.Text = "주방 - 레시피보기";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(14, 376);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(79, 12);
            this.label11.TabIndex = 37;
            this.label11.Text = "전광판 - 날씨";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(14, 584);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(103, 12);
            this.label12.TabIndex = 38;
            this.label12.Text = "도어락 - 암호관리";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(486, 16);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(139, 12);
            this.label13.TabIndex = 39;
            this.label13.Text = "테스트 - 임의문자보내기";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label16);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Controls.Add(this.label14);
            this.groupBox5.Controls.Add(this.initPasswordBtn);
            this.groupBox5.Controls.Add(this.changePasswordBtn);
            this.groupBox5.Controls.Add(this.confirmPassword);
            this.groupBox5.Controls.Add(this.newPassword);
            this.groupBox5.Controls.Add(this.currentPassword);
            this.groupBox5.Location = new System.Drawing.Point(14, 631);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(458, 72);
            this.groupBox5.TabIndex = 40;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Password Changer";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(219, 22);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 12);
            this.label16.TabIndex = 7;
            this.label16.Text = "암호확인";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(112, 22);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 12);
            this.label15.TabIndex = 6;
            this.label15.Text = "새로운암호";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 22);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 12);
            this.label14.TabIndex = 5;
            this.label14.Text = "현재암호";
            // 
            // initPasswordBtn
            // 
            this.initPasswordBtn.Location = new System.Drawing.Point(362, 42);
            this.initPasswordBtn.Name = "initPasswordBtn";
            this.initPasswordBtn.Size = new System.Drawing.Size(75, 23);
            this.initPasswordBtn.TabIndex = 4;
            this.initPasswordBtn.Text = "초기화";
            this.initPasswordBtn.UseVisualStyleBackColor = true;
            this.initPasswordBtn.Click += new System.EventHandler(this.initPasswordBtn_Click);
            // 
            // changePasswordBtn
            // 
            this.changePasswordBtn.Location = new System.Drawing.Point(362, 14);
            this.changePasswordBtn.Name = "changePasswordBtn";
            this.changePasswordBtn.Size = new System.Drawing.Size(75, 23);
            this.changePasswordBtn.TabIndex = 3;
            this.changePasswordBtn.Text = "변경";
            this.changePasswordBtn.UseVisualStyleBackColor = true;
            this.changePasswordBtn.Click += new System.EventHandler(this.changePasswordBtn_Click);
            // 
            // confirmPassword
            // 
            this.confirmPassword.Location = new System.Drawing.Point(221, 40);
            this.confirmPassword.Name = "confirmPassword";
            this.confirmPassword.Size = new System.Drawing.Size(100, 21);
            this.confirmPassword.TabIndex = 2;
            this.confirmPassword.TextChanged += new System.EventHandler(this.confirmPassword_TextChanged);
            // 
            // newPassword
            // 
            this.newPassword.Location = new System.Drawing.Point(114, 40);
            this.newPassword.Name = "newPassword";
            this.newPassword.Size = new System.Drawing.Size(100, 21);
            this.newPassword.TabIndex = 1;
            this.newPassword.TextChanged += new System.EventHandler(this.newPassword_TextChanged);
            // 
            // currentPassword
            // 
            this.currentPassword.Location = new System.Drawing.Point(7, 40);
            this.currentPassword.Name = "currentPassword";
            this.currentPassword.Size = new System.Drawing.Size(100, 21);
            this.currentPassword.TabIndex = 0;
            this.currentPassword.TextChanged += new System.EventHandler(this.currentPassword_TextChanged);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label21);
            this.groupBox6.Controls.Add(this.label20);
            this.groupBox6.Controls.Add(this.label19);
            this.groupBox6.Controls.Add(this.label18);
            this.groupBox6.Controls.Add(this.label17);
            this.groupBox6.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox6.Location = new System.Drawing.Point(489, 621);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(275, 82);
            this.groupBox6.TabIndex = 41;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "포트 값";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("굴림", 10F);
            this.label21.ForeColor = System.Drawing.Color.Crimson;
            this.label21.Location = new System.Drawing.Point(5, 61);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(261, 14);
            this.label21.TabIndex = 4;
            this.label21.Text = "이 포트번호는 추후 변경될 수 있습니다.";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(130, 40);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(104, 12);
            this.label20.TabIndex = 3;
            this.label20.Text = "4. 도어락 - COM4";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(20, 40);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(104, 12);
            this.label19.TabIndex = 2;
            this.label19.Text = "3. 전광판 - COM8";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(131, 19);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(92, 12);
            this.label18.TabIndex = 1;
            this.label18.Text = "2. 주방 - COM2";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(20, 19);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(92, 12);
            this.label17.TabIndex = 0;
            this.label17.Text = "1. 서재 - COM1";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("휴먼둥근헤드라인", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label23.Location = new System.Drawing.Point(709, 710);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(55, 11);
            this.label23.TabIndex = 6;
            this.label23.Text = "in 2011";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("휴먼옛체", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label22.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label22.Location = new System.Drawing.Point(588, 705);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(120, 17);
            this.label22.TabIndex = 5;
            this.label22.Text = "Made by LINK";
            // 
            // indicatorStr1
            // 
            this.indicatorStr1.AutoSize = true;
            this.indicatorStr1.Location = new System.Drawing.Point(56, 46);
            this.indicatorStr1.Name = "indicatorStr1";
            this.indicatorStr1.Size = new System.Drawing.Size(69, 12);
            this.indicatorStr1.TabIndex = 42;
            this.indicatorStr1.Text = "-- 연결안됨";
            // 
            // indicatorStr2
            // 
            this.indicatorStr2.AutoSize = true;
            this.indicatorStr2.Location = new System.Drawing.Point(56, 69);
            this.indicatorStr2.Name = "indicatorStr2";
            this.indicatorStr2.Size = new System.Drawing.Size(69, 12);
            this.indicatorStr2.TabIndex = 43;
            this.indicatorStr2.Text = "-- 연결안됨";
            // 
            // indicatorStr3
            // 
            this.indicatorStr3.AutoSize = true;
            this.indicatorStr3.Location = new System.Drawing.Point(56, 91);
            this.indicatorStr3.Name = "indicatorStr3";
            this.indicatorStr3.Size = new System.Drawing.Size(69, 12);
            this.indicatorStr3.TabIndex = 44;
            this.indicatorStr3.Text = "-- 연결안됨";
            // 
            // indicatorStr4
            // 
            this.indicatorStr4.AutoSize = true;
            this.indicatorStr4.Location = new System.Drawing.Point(56, 114);
            this.indicatorStr4.Name = "indicatorStr4";
            this.indicatorStr4.Size = new System.Drawing.Size(69, 12);
            this.indicatorStr4.TabIndex = 45;
            this.indicatorStr4.Text = "-- 연결안됨";
            // 
            // indicatorStr5
            // 
            this.indicatorStr5.AutoSize = true;
            this.indicatorStr5.Location = new System.Drawing.Point(56, 137);
            this.indicatorStr5.Name = "indicatorStr5";
            this.indicatorStr5.Size = new System.Drawing.Size(69, 12);
            this.indicatorStr5.TabIndex = 43;
            this.indicatorStr5.Text = "-- 연결안됨";
            // 
            // indicatorStr6
            // 
            this.indicatorStr6.AutoSize = true;
            this.indicatorStr6.Location = new System.Drawing.Point(131, 46);
            this.indicatorStr6.Name = "indicatorStr6";
            this.indicatorStr6.Size = new System.Drawing.Size(33, 12);
            this.indicatorStr6.TabIndex = 46;
            this.indicatorStr6.Text = "    --";
            // 
            // indicatorStr7
            // 
            this.indicatorStr7.AutoSize = true;
            this.indicatorStr7.Location = new System.Drawing.Point(131, 69);
            this.indicatorStr7.Name = "indicatorStr7";
            this.indicatorStr7.Size = new System.Drawing.Size(33, 12);
            this.indicatorStr7.TabIndex = 46;
            this.indicatorStr7.Text = "    --";
            // 
            // indicatorStr8
            // 
            this.indicatorStr8.AutoSize = true;
            this.indicatorStr8.Location = new System.Drawing.Point(131, 91);
            this.indicatorStr8.Name = "indicatorStr8";
            this.indicatorStr8.Size = new System.Drawing.Size(33, 12);
            this.indicatorStr8.TabIndex = 46;
            this.indicatorStr8.Text = "    --";
            // 
            // indicatorStr9
            // 
            this.indicatorStr9.AutoSize = true;
            this.indicatorStr9.Location = new System.Drawing.Point(131, 114);
            this.indicatorStr9.Name = "indicatorStr9";
            this.indicatorStr9.Size = new System.Drawing.Size(33, 12);
            this.indicatorStr9.TabIndex = 46;
            this.indicatorStr9.Text = "    --";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.button1);
            this.groupBox7.Controls.Add(this.label31);
            this.groupBox7.Controls.Add(this.indicatorStr5);
            this.groupBox7.Controls.Add(this.label30);
            this.groupBox7.Controls.Add(this.indicatorStr13);
            this.groupBox7.Controls.Add(this.indicatorStr12);
            this.groupBox7.Controls.Add(this.indicatorStr11);
            this.groupBox7.Controls.Add(this.indicatorStr10);
            this.groupBox7.Controls.Add(this.indicatorStr9);
            this.groupBox7.Controls.Add(this.label29);
            this.groupBox7.Controls.Add(this.label28);
            this.groupBox7.Controls.Add(this.indicatorStr8);
            this.groupBox7.Controls.Add(this.label24);
            this.groupBox7.Controls.Add(this.indicatorStr7);
            this.groupBox7.Controls.Add(this.label25);
            this.groupBox7.Controls.Add(this.indicatorStr6);
            this.groupBox7.Controls.Add(this.label26);
            this.groupBox7.Controls.Add(this.label32);
            this.groupBox7.Controls.Add(this.label27);
            this.groupBox7.Controls.Add(this.indicatorStr1);
            this.groupBox7.Controls.Add(this.indicatorStr2);
            this.groupBox7.Controls.Add(this.indicatorStr3);
            this.groupBox7.Controls.Add(this.indicatorStr4);
            this.groupBox7.Location = new System.Drawing.Point(489, 197);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(275, 159);
            this.groupBox7.TabIndex = 47;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "포트 상태";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(194, 132);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 47;
            this.button1.Text = "Reset";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(202, 21);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(65, 12);
            this.label31.TabIndex = 0;
            this.label31.Text = "DATA 송신";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(131, 21);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(65, 12);
            this.label30.TabIndex = 0;
            this.label30.Text = "DATA 수신";
            // 
            // indicatorStr13
            // 
            this.indicatorStr13.AutoSize = true;
            this.indicatorStr13.Location = new System.Drawing.Point(202, 114);
            this.indicatorStr13.Name = "indicatorStr13";
            this.indicatorStr13.Size = new System.Drawing.Size(33, 12);
            this.indicatorStr13.TabIndex = 46;
            this.indicatorStr13.Text = "    --";
            // 
            // indicatorStr12
            // 
            this.indicatorStr12.AutoSize = true;
            this.indicatorStr12.Location = new System.Drawing.Point(202, 91);
            this.indicatorStr12.Name = "indicatorStr12";
            this.indicatorStr12.Size = new System.Drawing.Size(33, 12);
            this.indicatorStr12.TabIndex = 46;
            this.indicatorStr12.Text = "    --";
            // 
            // indicatorStr11
            // 
            this.indicatorStr11.AutoSize = true;
            this.indicatorStr11.Location = new System.Drawing.Point(202, 69);
            this.indicatorStr11.Name = "indicatorStr11";
            this.indicatorStr11.Size = new System.Drawing.Size(33, 12);
            this.indicatorStr11.TabIndex = 46;
            this.indicatorStr11.Text = "    --";
            // 
            // indicatorStr10
            // 
            this.indicatorStr10.AutoSize = true;
            this.indicatorStr10.Location = new System.Drawing.Point(202, 46);
            this.indicatorStr10.Name = "indicatorStr10";
            this.indicatorStr10.Size = new System.Drawing.Size(33, 12);
            this.indicatorStr10.TabIndex = 46;
            this.indicatorStr10.Text = "    --";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(65, 21);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(53, 12);
            this.label29.TabIndex = 0;
            this.label29.Text = "연결여부";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(9, 21);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(29, 12);
            this.label28.TabIndex = 0;
            this.label28.Text = "위치";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(8, 46);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(29, 12);
            this.label24.TabIndex = 0;
            this.label24.Text = "서재";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(8, 69);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(29, 12);
            this.label25.TabIndex = 1;
            this.label25.Text = "주방";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(8, 91);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(41, 12);
            this.label26.TabIndex = 2;
            this.label26.Text = "전광판";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(8, 137);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(41, 12);
            this.label32.TabIndex = 3;
            this.label32.Text = "테스트";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(8, 114);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(41, 12);
            this.label27.TabIndex = 3;
            this.label27.Text = "도어락";
            // 
            // Indicator_socket
            // 
            this.Indicator_socket.AutoSize = true;
            this.Indicator_socket.Location = new System.Drawing.Point(144, 48);
            this.Indicator_socket.Name = "Indicator_socket";
            this.Indicator_socket.Size = new System.Drawing.Size(57, 12);
            this.Indicator_socket.TabIndex = 48;
            this.Indicator_socket.Text = "접속 끊김";
            // 
            // socketport
            // 
            this.socketport.Location = new System.Drawing.Point(86, 43);
            this.socketport.Name = "socketport";
            this.socketport.Size = new System.Drawing.Size(38, 21);
            this.socketport.TabIndex = 55;
            this.socketport.Text = "9998";
            // 
            // socketip
            // 
            this.socketip.Location = new System.Drawing.Point(27, 18);
            this.socketip.Name = "socketip";
            this.socketip.Size = new System.Drawing.Size(97, 21);
            this.socketip.TabIndex = 54;
            // 
            // socketportLabel
            // 
            this.socketportLabel.AutoSize = true;
            this.socketportLabel.Font = new System.Drawing.Font("굴림", 9F);
            this.socketportLabel.Location = new System.Drawing.Point(6, 47);
            this.socketportLabel.Name = "socketportLabel";
            this.socketportLabel.Size = new System.Drawing.Size(76, 12);
            this.socketportLabel.TabIndex = 53;
            this.socketportLabel.Text = "Port Number";
            // 
            // socketipLabel
            // 
            this.socketipLabel.AutoSize = true;
            this.socketipLabel.Location = new System.Drawing.Point(7, 21);
            this.socketipLabel.Name = "socketipLabel";
            this.socketipLabel.Size = new System.Drawing.Size(16, 12);
            this.socketipLabel.TabIndex = 52;
            this.socketipLabel.Text = "IP";
            // 
            // socket_discon
            // 
            this.socket_discon.Location = new System.Drawing.Point(202, 16);
            this.socket_discon.Name = "socket_discon";
            this.socket_discon.Size = new System.Drawing.Size(68, 23);
            this.socket_discon.TabIndex = 51;
            this.socket_discon.Text = "서버 정지";
            this.socket_discon.UseVisualStyleBackColor = true;
            this.socket_discon.Click += new System.EventHandler(this.socket_discon_Click);
            // 
            // socket_connect
            // 
            this.socket_connect.Location = new System.Drawing.Point(131, 16);
            this.socket_connect.Name = "socket_connect";
            this.socket_connect.Size = new System.Drawing.Size(67, 23);
            this.socket_connect.TabIndex = 50;
            this.socket_connect.Text = "서버 시작";
            this.socket_connect.UseVisualStyleBackColor = true;
            this.socket_connect.Click += new System.EventHandler(this.socket_connect_Click);
            // 
            // recive_socketTextBox
            // 
            this.recive_socketTextBox.Location = new System.Drawing.Point(5, 82);
            this.recive_socketTextBox.Name = "recive_socketTextBox";
            this.recive_socketTextBox.Size = new System.Drawing.Size(267, 160);
            this.recive_socketTextBox.TabIndex = 49;
            this.recive_socketTextBox.Text = "";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(5, 69);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(86, 12);
            this.label38.TabIndex = 3;
            this.label38.Text = "Received Data";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.socket_discon);
            this.groupBox10.Controls.Add(this.label38);
            this.groupBox10.Controls.Add(this.Indicator_socket);
            this.groupBox10.Controls.Add(this.recive_socketTextBox);
            this.groupBox10.Controls.Add(this.socket_connect);
            this.groupBox10.Controls.Add(this.socketipLabel);
            this.groupBox10.Controls.Add(this.socketportLabel);
            this.groupBox10.Controls.Add(this.socketip);
            this.groupBox10.Controls.Add(this.socketport);
            this.groupBox10.Location = new System.Drawing.Point(489, 362);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(275, 248);
            this.groupBox10.TabIndex = 49;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Mobile";
            // 
            // formCloseBtn
            // 
            this.formCloseBtn.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.formCloseBtn.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.formCloseBtn.Location = new System.Drawing.Point(676, 5);
            this.formCloseBtn.Name = "formCloseBtn";
            this.formCloseBtn.Size = new System.Drawing.Size(94, 23);
            this.formCloseBtn.TabIndex = 51;
            this.formCloseBtn.Text = "서버 종료하기";
            this.formCloseBtn.UseVisualStyleBackColor = false;
            this.formCloseBtn.Click += new System.EventHandler(this.button2_Click);
            // 
            // LEDControlSystemMainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(776, 724);
            this.Controls.Add(this.formCloseBtn);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.connectTest);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.portComboBox4);
            this.Controls.Add(this.passDisconnectBtn);
            this.Controls.Add(this.passConnectBtn);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.refreshCookButton);
            this.Controls.Add(this.refreshNewsButton);
            this.Controls.Add(this.portComboBox5);
            this.Controls.Add(this.portComboBox3);
            this.Controls.Add(this.portComboBox2);
            this.Controls.Add(this.portComboBox1);
            this.Controls.Add(this.submitTest);
            this.Controls.Add(this.disconnectTest);
            this.Controls.Add(this.disconnectWeatherButton);
            this.Controls.Add(this.connectWeatherButton);
            this.Controls.Add(this.disconnectCookButton);
            this.Controls.Add(this.connectCookButton);
            this.Controls.Add(this.disconnectNewsButton);
            this.Controls.Add(this.connectNewsButton);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Location = new System.Drawing.Point(10, 10);
            this.Name = "LEDControlSystemMainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = " ";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button connectNewsButton;
        private System.Windows.Forms.Button disconnectNewsButton;
        private System.Windows.Forms.Button disconnectCookButton;
        private System.Windows.Forms.Button connectCookButton;
        private System.Windows.Forms.Button disconnectWeatherButton;
        private System.Windows.Forms.Button connectWeatherButton;
        private System.Windows.Forms.Button disconnectTest;
        private System.Windows.Forms.Button connectTest;
        private System.Windows.Forms.Button submitTest;
        private System.Windows.Forms.ComboBox portComboBox1;
        private System.Windows.Forms.ComboBox portComboBox2;
        private System.Windows.Forms.ComboBox portComboBox3;
        private System.Windows.Forms.ComboBox portComboBox5;
        private System.Windows.Forms.RichTextBox newsTextBox;
        private System.Windows.Forms.RichTextBox cookTextBox;
        private System.Windows.Forms.RichTextBox testWriteTextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RichTextBox testReadTextBox;
        private System.IO.Ports.SerialPort serialTest;
        private System.IO.Ports.SerialPort serialNews;
        private System.IO.Ports.SerialPort serialCook;
        private System.IO.Ports.SerialPort serialWeather;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button submitWeatherButton;
        private System.Windows.Forms.Button refreshNewsButton;
        private System.Windows.Forms.Button refreshCookButton;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox weatherTextBox;
        private System.IO.Ports.SerialPort serialPassword;
        private System.Windows.Forms.ComboBox portComboBox4;
        private System.Windows.Forms.Button passDisconnectBtn;
        private System.Windows.Forms.Button passConnectBtn;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button initPasswordBtn;
        private System.Windows.Forms.Button changePasswordBtn;
        private System.Windows.Forms.TextBox confirmPassword;
        private System.Windows.Forms.TextBox newPassword;
        private System.Windows.Forms.TextBox currentPassword;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label indicatorStr1;
        private System.Windows.Forms.Label indicatorStr2;
        private System.Windows.Forms.Label indicatorStr3;
        private System.Windows.Forms.Label indicatorStr4;
        private System.Windows.Forms.Label indicatorStr5;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label indicatorStrDW;
        private System.Windows.Forms.Label indicatorStr6;
        private System.Windows.Forms.Label indicatorStr7;
        private System.Windows.Forms.Label indicatorStr8;
        private System.Windows.Forms.Label indicatorStr9;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label indicatorStr13;
        private System.Windows.Forms.Label indicatorStr12;
        private System.Windows.Forms.Label indicatorStr11;
        private System.Windows.Forms.Label indicatorStr10;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label Indicator_socket;
        private System.Windows.Forms.RichTextBox recive_socketTextBox;
        private System.Windows.Forms.Button socket_connect;
        private System.Windows.Forms.Button socket_discon;
        private System.Windows.Forms.TextBox socketport;
        private System.Windows.Forms.TextBox socketip;
        private System.Windows.Forms.Label socketportLabel;
        private System.Windows.Forms.Label socketipLabel;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Button formCloseBtn;
    }
}

