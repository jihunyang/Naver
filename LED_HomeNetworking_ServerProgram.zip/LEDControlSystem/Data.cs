﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LEDControlSystem
{
    public class Data : ICloneable
    {
        private string m_title;
        private string m_exp;

        public Data()
        {
            this.m_title = null;
            this.m_exp = null;

        }
        public Data(string m_title, string m_exp)
        {
            this.m_title = m_title;
            this.m_exp = m_exp;
 

        }

        public string Title
        {
            get
            {
                return m_title;
            }

            set
            {
                m_title = value;
            }
        }

        public string Exp
        {
            get
            {
                return m_exp;
            }

            set
            {
                m_exp = value;
            }
        }
       
        #region ICloneable Members
        public virtual object Clone()
        {
            return new Data(m_title, m_exp);
        }
        #endregion
    }
}
