﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;

namespace LEDControlSystem
{
    public class DataList : Data
    {
        protected ArrayList m_list;

        public override Object Clone()
        {
            DataList rtn = new DataList();

            for (int i = 0; i < m_list.Count; i++)
                rtn.Add((Data)this[i].Clone());

            return rtn;
        }


        public DataList()
            : base(null, null)
        {
            m_list = new ArrayList();
        }

        public void Add(Data a)
        {
            m_list.Add(a);
        }

        public void Clear()
        {
            m_list.Clear();
        }

        public bool IsEmpty()
        {
            return (m_list.Count <= 0);
        }

        public void Set(string title, string exp)
        {
            if (title == null)
                return;
            if (exp == null)
                exp = "";
            Data a = new Data(title, exp);
            Add(a);
        }

        public int Count
        {
            get
            {
                return m_list.Count;
            }
        }

        public ArrayList List
        {
            get
            {
                return m_list;
            }
        }

        public Data this[int index]
        {
            get
            {
                if (index < m_list.Count)
                    return (Data)m_list[index];
                else
                    return null;
            }
        }
    }
}
