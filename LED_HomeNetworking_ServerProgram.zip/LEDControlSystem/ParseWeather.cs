﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Net;
using System.IO;
using HtmlAgilityPack;

namespace LEDControlSystem
{

    class ParseWeather : Data
    {
        private DataList list;
        private WebRequest request;
        private HttpWebResponse response;
        private Stream dataStream;
        private HtmlAgilityPack.HtmlDocument doc;
        private string url;

        public ParseWeather()
        {
            url = "http://weather.media.daum.net/?pageId=103&metro=M090&area=11F20501";
            request = WebRequest.Create(url);
            request.Credentials = CredentialCache.DefaultCredentials;
            response = (HttpWebResponse)request.GetResponse();
            dataStream = response.GetResponseStream();
            doc = new HtmlAgilityPack.HtmlDocument();
            doc.Load(dataStream, Encoding.UTF8);
            list = new DataList();
        }

        public DataList getDataList()
        {
            return list;
        }

        public void parse(){
            list.Clear();
            HtmlNodeCollection nodeList = doc.DocumentNode.SelectNodes("//dl[@id='Detail_wt']");
            foreach (HtmlNode node in nodeList)
            {
                HtmlNodeCollection subNodeList = node.SelectNodes(".//p[@class='dt2']");
                foreach (HtmlNode subNode in subNodeList)
                {
                    Data data = new Data();
                    data.Title = subNode.InnerText;
                    data.Title = data.Title.Trim();
                    data.Exp = "";//본문이 필요할시 여기에서 추가
                    list.Add(data);
                }
                
            }
            foreach (HtmlNode node in nodeList)
            {
                HtmlNodeCollection subNodeList = node.SelectNodes(".//span[@class='d_date']");
                foreach (HtmlNode subNode in subNodeList)
                {
                    Data data = new Data();
                    data.Title = subNode.InnerText;
                    data.Title = data.Title.Trim();
                    data.Exp = "";//본문이 필요할시 여기에서 추가
                    list.Add(data);
                }
            }
        }
    }
}
