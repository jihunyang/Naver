﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Net;
using System.IO;
using HtmlAgilityPack;
namespace LEDControlSystem
{
    class ParseCook
    {
        private DataList list;
        private WebRequest request;
        private HttpWebResponse response;
        private Stream dataStream;
        private HtmlAgilityPack.HtmlDocument doc;
        private string url;

        public ParseCook()
        {
            url = "http://food4.net/zeroboard/zboard.php?id=reci&page=3&sn1=&divpage=1&sn=off&ss=on&sc=on&select_arrange=headnum&desc=asc&no=56";
            request = WebRequest.Create(url);
            request.Credentials = CredentialCache.DefaultCredentials;
            response = (HttpWebResponse)request.GetResponse();
            dataStream = response.GetResponseStream();
            doc = new HtmlAgilityPack.HtmlDocument();
            doc.Load(dataStream, Encoding.Default);
            list = new DataList();
        }

        public DataList getDataList()
        {
            return list;
        }

        public void parse(){
            list.Clear();
            HtmlNodeCollection nodeList = doc.DocumentNode.SelectNodes("//td[@class='list_han']");
            foreach (HtmlNode node in nodeList)
            {
                Data data = new Data();

                data.Title = node.InnerText.ToString().Replace("&nbsp;", "");
                int lastIndex = data.Title.IndexOf("2007.");

                data.Title = data.Title.Substring(100, lastIndex);
                data.Title = data.Title.Replace("\r\n", "");
                data.Title = data.Title.Replace("\n", "");
                

                data.Exp = "";//본문이 필요할시 여기에서 추가
                list.Add(data);
            }
        }
    }
}
